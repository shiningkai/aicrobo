'use strict';

module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    clean: {
      src: ['../mapview']
    },
    copy: {
      main: {
        files: [
          {expand: true, flatten: true, src: ['../themes/material/images/*'], dest: '../mapview/images', filter: 'isFile'},
          {expand: true, flatten: true, src: ['../themes/icons/*'], dest: '../mapview/icons', filter: 'isFile'}
        ]
      }
    },
    htmlmin: {
      dist: {
        options: {
          removeComments: true,
          collapseWhitespace: true
        },
        files: {
          '../mapview/index.html': 'src/index.html'
        }
      }
    },
    cssmin: {
      options: {
        shorthandCompacting: false,
        roundingPrecision: -1
      },
      target: {
        files: {
          '../mapview/index.min.css': ['../themes/material/easyui.css', '../themes/icon.css', '../demo.css']
        }
      }
    },
    concat: {
      options: {
      separator: ';'
      },
      dist: {
        src: ['libs/jquery.min.js', 
              'libs/jquery.easyui.min.js',
              'libs/local/easyui-lang-zh_CN.js',
              'libs/fabric.min.js',
              'src/robot_ctrl.js',
              'src/index.js'],
        dest: '../mapview/index.js',
      }
    },
    uglify: {
      options: {
        mangle: {
          eval: true,
          toplevel: false
        },
        compress: {
          drop_console: false,
          dead_code: true,
          warnings: false,
          collapse_vars: true,
          reduce_vars: true,
          comparisons: true,
          //hoist_funs: true,
          hoist_vars: true,
          join_vars: true,
          unsafe: true,
          loops: true
        },
        beautify: false,
        banner: '/*\n <%= pkg.name %> [<%= grunt.template.today("yyyy-mm-dd") %>]\n author: <%= pkg.author %>\n mail: <%= pkg.mail %>\n*/\n'
      },
      build: {
        src: '<%= concat.dist.dest %>',
        dest: '../mapview/index.min.js'
      }
    }
  });

  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-htmlmin');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-uglify');

  grunt.registerTask('default', ['clean', 'copy', 'htmlmin', 'cssmin', 'concat', 'uglify']);
  grunt.registerTask('html', ['htmlmin', 'cssmin']);


};
