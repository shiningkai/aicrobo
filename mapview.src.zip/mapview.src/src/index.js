var SCALE_FACTOR                    = 1.1;
var CANVAS_MAX_AREA                 = 268435456;


var clickX = -1;
var clickY = -1;
var moveX = -1;
var moveY = -1;
var scrollX = -1;
var scrollY = -1;
var arrowX = -1000;
var arrowY = -1000;
var robotX = -1000;
var robotY = -1000;
var robotAngle = 0;
var robotAccuracy = 0;
var path = "../";
var dragmove = false;
var arrowSrc = path + "images/svg/target_set.svg";
var arrowObj = null;
var robotSrc = path + "images/svg/arrow_blue.svg";
var robotObj = null;
var nodeSrc = path + "images/svg/target.svg";
var nodeObj = null;
var gridObj = null;                     //网格

var URL_SENDCTRL = path + "php/sendctrl.php";
var URL_SENDDATA = path + 'php/client.php';

var isBtnPressed = false;
var isKeyDown = false;
var canvas;
var timerCmd;                           //任务持续发送定时器
var frequenceCmd = 200;                 //任务持续发送频率
var timerMap;                           //地图刷新定时器
var frequenceMap = 2000;                //地图刷新频率
var timerAnimateRobot;                  //机器人图标闪烁定时器
var frequenceAnimateRobot = 800;        //机器人图标闪烁频率
var bgImg;
var dragmove = false;
var drawMode = DRAW_MODE_BROWSE;
var svgSize = 30;
var mapName = "map";
var pathLines = new Array();



function initNavWin() {
    var img = $("#graph-nav");
    var scaleRate = 298 / canvas.getWidth();
    var dataURL = canvas.toDataURL({
        format: 'jpeg',
        quality: 1,
        multiplier: scaleRate
    });
    img.attr("src", dataURL);
    img.unbind("click");
    img.bind("click", function (event) {
        var width = $(this)[0].clientWidth;
        var height = $(this)[0].clientHeight;
        var map_div = $("#map_div");
        var navX = event.offsetX;
        var navY = event.offsetY;
        map_div.scrollLeft((navX / width) * canvas.getWidth() - map_div[0].clientWidth / 2);
        map_div.scrollTop((navY / height) * canvas.getHeight() - map_div[0].clientHeight / 2);
    });
    $('#map_win').window('open');
}

function updateTargetProperty(x, y, angle){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[0].value = (x / canvasScale) * mapResolution + mapOriginX;
    rows[1].value = mapHeight * mapResolution - (y / canvasScale) * mapResolution + mapOriginY;
    rows[2].value = angle;

    $('#map_pg').propertygrid('refreshRow', 0);
    $('#map_pg').propertygrid('refreshRow', 1);
    $('#map_pg').propertygrid('refreshRow', 2);
}

function updateMapProperty(){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[7].value = mapResolution;
    rows[8].value = mapOriginX;
    rows[9].value = mapOriginY;

    $('#map_pg').propertygrid('refreshRow', 7);
    $('#map_pg').propertygrid('refreshRow', 8);
    $('#map_pg').propertygrid('refreshRow', 9);
}

function updateRobotAccuracy(accuracy){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[6].value = accuracy;

    $('#map_pg').propertygrid('refreshRow', 6);
}

function updateRobotProperty(posx, posy, direction){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[3].value = posx;
    rows[4].value = posy;
    rows[5].value = direction;

    $('#map_pg').propertygrid('refreshRow', 3);
    $('#map_pg').propertygrid('refreshRow', 4);
    $('#map_pg').propertygrid('refreshRow', 5);
}

function updatePathPointProperty(id, code, name, x, y, angle, deviation){
    var rows = $('#edit_pg').propertygrid('getRows');

    rows[0].value = id;
    rows[1].value = code;
    rows[2].value = name;
    rows[3].value = pixToPos(x / canvasScale, y / canvasScale).posx;
    rows[4].value = pixToPos(x / canvasScale, y / canvasScale).posy;
    rows[5].value = angleToDirection(angle);
    rows[6].value = deviation;

    $('#edit_pg').propertygrid('refreshRow', 0);
    $('#edit_pg').propertygrid('refreshRow', 1);
    $('#edit_pg').propertygrid('refreshRow', 2);
    $('#edit_pg').propertygrid('refreshRow', 3);
    $('#edit_pg').propertygrid('refreshRow', 4);
    $('#edit_pg').propertygrid('refreshRow', 5);
    $('#edit_pg').propertygrid('refreshRow', 6);
}

function updateRobotPosition(posx, posy, direction){
    var pix = posToPix(posx, posy);
    robotX = pix.x;
    robotY = pix.y;
    robotAngle = directionToAngle(direction);

    robotObj.set({ left: Math.round(robotX * canvasScale), top: Math.round(robotY * canvasScale), angle: robotAngle});
    canvas.fire('object:modified', {target: robotObj});
    canvas.renderAll();

    updateRobotProperty(posx, posy, direction);
}


var iopacity = 0.8;

function startAnimateRobot(){
    clearInterval(timerAnimateRobot);
    timerAnimateRobot =  self.setInterval(function(){
        robotObj.set({ opacity: iopacity});
        if(drawMode == DRAW_MODE_SET_EDIT){
            canvas.sendToBack(robotObj);
        }else{
            canvas.bringToFront(robotObj);
        }
        canvas.fire('object:modified', {target: robotObj});
        canvas.renderAll();
        if(iopacity == 0.2){
            iopacity = 0.8;
        }else{
            iopacity = 0.2;
        }
    },frequenceAnimateRobot);
}

function stopAnimateRobot(){
    clearInterval(timerAnimateRobot);
}

function startRefreshingMap(){
    clearInterval(timerMap);
    timerMap =  self.setInterval(function(){
        reloadMap();
    },frequenceMap);
}

function stopRefreshingMap(){
    clearInterval(timerMap);
}

function reloadMap(){

    $('#map_win').window('close');

    var date = new Date();
    var timestamp = date.getTime();

    canvas.setBackgroundImage(0);

    fabric.Image.fromURL(path + 'map/' + mapName + '.jpg?timestamp=' + timestamp, function(oImg) {

        bgImg = oImg;

        bgImg.scale(canvasScale);

        mapWidth = bgImg.getWidth();
        mapHeight = bgImg.getHeight();

        canvas.setBackgroundImage(bgImg);

        canvas.setWidth(mapWidth);
        canvas.setHeight(mapHeight);

        canvas.calcOffset();

        canvas.renderAll();

        loadMapSettings();
    });
}

function setDrawMode(mode){
    switch(mode){
        case DRAW_MODE_BROWSE:
        if(canvas){canvas.selection = false;}
        if(arrowObj){arrowObj.visible = false;}

        $('#node_btn').hide();

        $('#addpathpoint_btn').hide();
        $('#removepathpoint_btn').hide();
        $('#connectpathpoint_btn').hide();
        $('#connectpathpointleft_btn').hide();
        $('#connectpathpointright_btn').hide();
        $('#disconnectpathpoint_btn').hide();
        //$('#savepathpoint_btn').hide();
        $('#lock_btn').hide();
        $('#unlock_btn').hide();
        $('#robot_btn').hide();

        //$('#layout').layout('collapse', 'west');
        //$('#layout').layout('collapse', 'east');

        enablePathPoints(false);
        //hidePathPoints();

        break;
        case DRAW_MODE_SET_DIRECTION:
        if(canvas){canvas.selection = false;}
        if(arrowObj){
            arrowObj.visible = true;
            canvas.bringToFront(arrowObj);
        }

        $('#node_btn').show();

        $('#addpathpoint_btn').hide();
        $('#removepathpoint_btn').hide();
        $('#connectpathpoint_btn').hide();
        $('#connectpathpointleft_btn').hide();
        $('#connectpathpointright_btn').hide();
        $('#disconnectpathpoint_btn').hide();
        //$('#savepathpoint_btn').hide();
        $('#lock_btn').hide();
        $('#unlock_btn').hide();
        $('#robot_btn').hide();

        $('#layout').layout('expand', 'west');
        //$('#layout').layout('collapse', 'east');

        enablePathPoints(false);
        //hidePathPoints();

        break;
        case DRAW_MODE_SET_EDIT:
        if(canvas){canvas.selection = true;}
        if(arrowObj){arrowObj.visible = false;}

        $('#node_btn').hide();

        $('#addpathpoint_btn').show();
        $('#removepathpoint_btn').show();
        $('#connectpathpoint_btn').show();
        $('#connectpathpointleft_btn').show();
        $('#connectpathpointright_btn').show();
        $('#disconnectpathpoint_btn').show();
        //$('#savepathpoint_btn').show();
        $('#lock_btn').show();
        $('#unlock_btn').show();
        $('#robot_btn').show();

        //$('#layout').layout('collapse', 'west');
        $('#layout').layout('expand', 'east');

        enablePathPoints(true);
        //showPathPoints();

        break;
        default:
        break;
    }
    drawMode = mode;
}

function startStopping(){
    clearInterval(timerCmd);
    timerCmd =  self.setInterval(function(){
        sendStoppingCtrl();
    },frequenceCmd);
}

function startMoving(cmd){
    clearInterval(timerCmd);
    timerCmd =  self.setInterval(function(){
        sendMovingCtrl(cmd);
    },frequenceCmd);
}

function sendStoppingCtrl(){
    postAjaxJsonRequest(
        URL_SENDCTRL,
        {
            action: CTRL_CODE_ROBOT_KEEPSTOP
        }, 
        function(obj){
            var request = {
                action: "sendctrl",
                data: obj.action
            }
            parent.sendmsg(JSON.stringify(request));
        },
        printAjaxResult
    );
}

function sendMovingCtrl(cmd){
    var speed;
    if(cmd == CTRL_CODE_ROBOT_FORWARD || cmd == CTRL_CODE_ROBOT_BACKWARD){
        speed = parseInt($('#movespeed_ns').val());
    }else if(cmd == CTRL_CODE_ROBOT_TURNLEFT || cmd == CTRL_CODE_ROBOT_TURNRIGHT){
        speed = parseInt($('#rotatespeed_ns').val());
    }
    //var speed = $("#rs_slider").slider("getValue");

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: cmd,
            speed: speed
        }, 
        function(obj){
            var request = {
                action: "sendctrl",
                data: obj.action
            }
            parent.sendmsg(JSON.stringify(request));
        },
        printAjaxResult
    );
}

function sendLocationCtrl(cmd){

    var data = $('#map_pg').propertygrid('getData');

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: cmd,
            posx: data.rows[0].value,
            posy: data.rows[1].value,
            direction: data.rows[2].value
        }, 
        function(obj){
            var request = {
                action: "sendctrl",
                data: obj.action
            }
            parent.sendmsg(JSON.stringify(request));
        },
        printAjaxResult
        );
}

function setDirection(){
    var direction = parseInt($('#angle_ns').val());
    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: CTRL_CODE_ROBOT_ROTATE,
            direction: direction
        }, 
        function(obj){
            var request = {
                action: "sendctrl",
                data: obj.action
            }
            parent.sendmsg(JSON.stringify(request));
        },
        printAjaxResult
    );
}

function stopMoving(){

    clearInterval(timerCmd);

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: CTRL_CODE_ROBOT_STOP
        }, 
        function(obj){
            var request = {
                action: "sendctrl",
                data: obj.action
            }
            parent.sendmsg(JSON.stringify(request));
        },
        printAjaxResult
    );
}

$(document).keydown(function(event){
    if(isKeyDown == false){
        switch(event.keyCode){
            case KEY_CODE_LEFT:
            startMoving(CTRL_CODE_ROBOT_TURNLEFT);
            break;
            case KEY_CODE_UP:
            startMoving(CTRL_CODE_ROBOT_FORWARD);
            break;
            case KEY_CODE_RIGHT:
            startMoving(CTRL_CODE_ROBOT_TURNRIGHT);
            break;
            case KEY_CODE_DOWN:
            startMoving(CTRL_CODE_ROBOT_BACKWARD);
            break;
            default:
            break;
        }
        isKeyDown = true;
    }
})

$(document).keyup(function(event){
    if(isKeyDown == true){
        switch(event.keyCode){
            case KEY_CODE_LEFT:
            case KEY_CODE_UP:
            case KEY_CODE_RIGHT:
            case KEY_CODE_DOWN:
            stopMoving();
            isKeyDown = false;
            break;
            default:
            break;
        }
    }
})


function onpress(cmd){
    isBtnPressed = true;
    switch(cmd){
        case CTRL_CODE_ROBOT_FORWARD:
        case CTRL_CODE_ROBOT_TURNLEFT:
        case CTRL_CODE_ROBOT_BACKWARD:
        case CTRL_CODE_ROBOT_TURNRIGHT:
        case CTRL_CODE_ROBOT_KEEPSTOP:
        startMoving(cmd);
        break;
        default:
        break;
    }
}

function onrelease(cmd){

    if(isBtnPressed){
        isBtnPressed = false;
        switch(cmd){
            case CTRL_CODE_ROBOT_STOP:
            stopMoving();
            break;
            default:
            break;
        }
    }
}

function zoomIn(){
    zoomTo(canvasScale + 0.1);
    $('#zoom_cb').combobox('setValue', parseInt(canvasScale * 100));
}

function zoomOut(){
    zoomTo(canvasScale - 0.1);
    $('#zoom_cb').combobox('setValue', parseInt(canvasScale * 100));
}

function zoomTo(factor) {

    if(canvas == null || !factor){
        return;
    }

    var newFactor = factor / canvasScale;

    var newScale = Math.round(canvasScale * newFactor * 10) / 10;

    if(newScale < 0.1 || newScale > 2){
        return;
    }

    canvasScale = newScale;

    canvas.deactivateAll();
    
    canvas.setHeight(canvas.getHeight() * newFactor);
    canvas.setWidth(canvas.getWidth() * newFactor);

    bgImg.scale(canvasScale);

    canvas.setBackgroundImage(bgImg);
    
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX,
        scaleY = objects[i].scaleY,
        left = objects[i].left,
        top = objects[i].top,
        tempScaleX = scaleX * newFactor,
        tempScaleY = scaleY * newFactor,
        tempLeft = left * newFactor,
        tempTop = top * newFactor;
        
        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;
        
        objects[i].setCoords();
    }

    canvas.renderAll();
}

function initPropertygrid(){

}

function loadMapSettings(){
    $.ajax({
        url: path + 'map/' + mapName + '.yaml',
        type: "GET",
        dataType: 'text',
        success: function (txt) {
            console.log(txt);
            var strs = new Array();
            strs = txt.split("\n");
            for(var i = 0; i < strs.length; i ++){
                if(strs[i].split(":")[0].trim() == "resolution"){
                    mapResolution = parseFloat(strs[i].split(":")[1]);
                }
                if(strs[i].split(":")[0].trim() == "origin"){
                    var origin = strs[i].split(":")[1].trim();
                    origin = origin.slice(1,origin.length - 1);
                    mapOriginX = parseFloat(origin.split(",")[0]);
                    mapOriginY = parseFloat(origin.split(",")[1]);
                }
            }

            var data = $('#map_pg').propertygrid('getData');
            if(data.total == 0){
                initPropertygrid();
            }else{
                updateMapProperty();
            }

            if(!canvas){
                initCanvas();
            }
        }
    });
}

function updateArrow(x1, y1, x2, y2){

    /*canvas.getObjects().map(function (o) {
        canvas.remove(o);
    });*/

    if(x2 < 0 || y2 < 0){
        arrowX = arrowObj.left;
        arrowY = arrowObj.top;
        arrowObj.set({ left: x1, top: y1, angle: 90});
        /*if(arrowX >= 0 && arrowY >= 0){
            var line = new fabric.Line([arrowX, arrowY, x1, y1], {
                selectable: false,
                strokeWidth: 5 * canvasScale,
                strokeDashArray: [8 * canvasScale, 2 * canvasScale],
                stroke: 'darkblue',
                opacity: 0.5
            });
            canvas.add(line);
        }*/
        arrowX = x1;
        arrowY = y1;
        canvas.fire('object:modified', {target: arrowObj});
        canvas.renderAll();

        updateTargetProperty(x1, y1, 0);
    }else{
        var x = Math.abs(x1 - x2);
        var y = Math.abs(y1 - y2);
        var z = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        var cos = y / z;
        var r = Math.acos(cos);
        var angle = 180 / (Math.PI / r);

        if(x2 > x1 && y2 > y1){
            angle = 180 - angle;
        }

        if(x2 == x1 && y2 > y1){
            angle = 180;
        }

        if(x2 > x1 && y2 == y1){
            angle = 90;
        }

        if(x2 < x1 && y2 > y1){
            angle = 180 + angle;
        }

        if(x2 < x1 && y2 == y1){
            angle = 270;
        }

        if(x2 < x1 && y2 < y1){
            angle = 360 - angle;
        }

        arrowObj.set({ left: x1, top: y1, angle: angle});

        canvas.fire('object:modified', {target: arrowObj});
        canvas.renderAll();

        angle = (angle - 90) < 0 ? 360 + (angle - 90) : angle - 90;

        updateTargetProperty(x1, y1, angle);
    }
}

function hidePathPoints(){

    if(canvas){

        canvas.deactivateAll();

        pathLines.forEach(function(obj){
            if(obj.line){
                canvas.remove(obj.line);
                canvas.remove(obj.triangle);
            }
        });

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    visible: false
                });
            }
        });

        canvas.renderAll();
    }
}

function showPathPoints(){

    if(canvas){

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    visible: true
                });
            }
        });

        pathLines.forEach(function(obj){
            repaintPathLine(obj);
        });

        canvas.renderAll();
    }
}

function enablePathPoints(enabled){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    lockMovementX: !enabled,
                    lockMovementY: !enabled,
                    lockRotation: !enabled,
                    hasBorders: enabled,
                    hasControls: enabled,
                    hasRotatingPoint: enabled
                });
            }
        });
    }
}

function lockPathPoints(){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    lockMovementX: true,
                    lockMovementY: true,
                    lockRotation: true,
                    hasBorders: false,
                    hasControls: false,
                    hasRotatingPoint: false
                });
            }
        });
    }
}

function unlockPathPoints(){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    lockMovementX: false,
                    lockMovementY: false,
                    lockRotation: false,
                    hasBorders: true,
                    hasControls: true,
                    hasRotatingPoint: true
                });
            }
        });
    }
}

function insertPathPoint(objects){

    var data = [];

    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "addpathpoint",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                if(obj.items){
                    for(var i = 0; i < obj.items.length; i ++){
                        objects[i].object.id = obj.items[i].id;
                    }
                    savePath();
                }
            }
        },
        printAjaxResult
        );
}


function sendMission(){
    var data = [];
    
    data.push({
        id: 127000001
    });
    data.push({
        id: 127000002
    });

    postAjaxJsonRequest(
        URL_SENDCTRL,
        {
            action: CTRL_CODE_MISSION_START,
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
            }
        },
        printAjaxResult
    );
}


function clearPathPoint(objects){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "clearpathpoint"
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                insertPathPoint(objects);
            }
        },
        printAjaxResult
    );
}

function insertPath(objects){

    var data = [];
    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "addpath",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
            }
        },
        printAjaxResult
    );
}

function clearPath(objects){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "clearpath"
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                insertPath(objects);
            }
        },
        printAjaxResult
        );
}

function updatePathPoint(objects){
    var data = [];

    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "setpathpoint",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                $.messager.alert("操作提示", "操作成功！","info", function(){
                });
            }
        },
        printAjaxResult
        );
}

function getPathPoint(){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "getpathpoint",
            startIndex: 0,
            endIndex: 1024
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }
            if(obj.items){
                for(var i = 0; i < obj.items.length; i ++){
                    var pix = posToPix(obj.items[i].pos_x, obj.items[i].pos_y);
                    var angle = directionToAngle(obj.items[i].pos_direct);
                    var clone = fabric.util.object.clone(nodeObj);
                    var width = nodeObj.width;
                    var height = nodeObj.height;
                    var scale = Math.min(svgSize / width, svgSize / height);
                    clone.set({
                        id: obj.items[i].id,
                        code: obj.items[i].code,
                        name: obj.items[i].name,
                        deviation: obj.items[i].deviation,
                        left: canvasScale * pix.x,
                        top: canvasScale * pix.y,
                        angle: angle,
                        scaleX: canvasScale * scale,
                        scaleY: canvasScale * scale,
                        objType: 'pathpoint',
                        //selectable: false
                        lockMovementX: true,
                        lockMovementY: true,
                        lockRotation: true,
                        hasBorders: false,
                        hasControls: false,
                        hasRotatingPoint: false
                    });
                    canvas.add(clone);
                }

                canvas.renderAll();

                getPath();
            }
        },
        printAjaxResult
        );
}

function getPath(){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "getpath",
            startIndex: 0,
            endIndex: 1024
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }
            if(obj.items){
                var pathPoints = [];

                var objects = canvas.getObjects("path-group");
                objects.forEach(function(obj){
                    if(obj.objType && obj.objType == "pathpoint"){
                        pathPoints.push(obj);
                    }
                });

                for(var i = 0; i < obj.items.length; i ++){
                    var startObject = getPathPointById(pathPoints, obj.items[i].start_point);
                    var endObject = getPathPointById(pathPoints, obj.items[i].end_point);
                    if(startObject != null && endObject != null){
                        pathLines.push({
                            id: obj.items[i].id,
                            startObject: startObject,
                            endObject: endObject,
                            type: obj.items[i].direction,
                            line: null,
                            triangle: null
                        });
                    }
                }

                pathLines.forEach(function(obj){
                    repaintPathLine(obj);
                });
            }
        },
        printAjaxResult
        );
}

function getPathPointById(pathPoints, id){
    for(var i = 0; i < pathPoints.length; i ++){
        if(pathPoints[i].id && pathPoints[i].id == id){
            return pathPoints[i];
        }
    }
    return null;
}

function savePathPoint(){

    canvas.deactivateAll();

    var pathPoints = [];

    var objects = canvas.getObjects("path-group");
    objects.forEach(function(obj){
        if(obj.objType && obj.objType == "pathpoint"){
            var pathPoint = new PathPoint(obj);
            pathPoints.push(pathPoint);
        }
    });

    clearPathPoint(pathPoints);
}

function savePath(){
    var paths = [];

    pathLines.forEach(function(object){
        var path = new Path(object);
        paths.push(path);
    });

    clearPath(paths);
}

//将机器人坐标复制到当前选中的路径节点
function cloneRobotPosition(){
    var activeObject = canvas.getActiveObject();
    if(robotObj && robotObj.left >= 0 && robotObj.top >= 0 && activeObject){
        canvas.deactivateAll();
        activeObject.set({
            left: robotObj.left,
            top: robotObj.top,
            angle: robotObj.angle
        });
        canvas.fire('object:modified', {target: activeObject});
        canvas.renderAll();
        canvas.setActiveObject(activeObject.setCoords());
    }
}

//重新绘制一条路径
function repaintPathLine(obj){
    if(obj.line){
        canvas.remove(obj.line);
        canvas.remove(obj.triangle);
    }

    var startObject = obj.startObject;
    var endObject = obj.endObject;
    var stroke = '#324D5B';
    var dashArray = [];
    var isArrow = false;

    switch(obj.type){
        case 0:
        isArrow = false;
        break;
        case 1:
        isArrow = true;
        dashArray = [8 * canvasScale, 2 * canvasScale];
        break;
        default:
        break;
    }

    var line = new fabric.Line([startObject.left, startObject.top, endObject.left, endObject.top],{
        left: Math.min(startObject.left, endObject.left) - 4 * canvasScale / 2,
        top: Math.min(startObject.top, endObject.top) - 4 * canvasScale / 2,
        selectable: false,
        strokeWidth: 4 * canvasScale,
        strokeDashArray: dashArray,
        stroke: stroke,
        opacity: 0.3
    });

    obj.line = line;
    
    canvas.add(line);
    canvas.sendToBack(line);

    if(isArrow){
        var x1 = startObject.left,
        y1 = startObject.top,
        x2 = endObject.left,
        y2 = endObject.top,
        dx = x2 - x1,
        dy = y2 - y1;

        var angle = Math.atan2(dy, dx);

        angle *= 180 / Math.PI;
        angle += 90;

        var triangle = new fabric.Triangle({
            left: x2 - dx / 2,
            top: y2 - dy / 2,
            height: 10 * canvasScale,
            width: 10 * canvasScale,
            angle: angle,
            fill: stroke,
            originX: 'center',
            originY: 'center',
            selectable: false,
            opacity: 0.3
        });

        obj.triangle = triangle;

        canvas.add(triangle);
        canvas.sendToBack(triangle);
    }
}

//为选中的两个路径节点添加连接线
function connectPathPoint(type) {

    var activeGroup = canvas.getActiveGroup();
    if (activeGroup) {
        var objectsInGroup = activeGroup.getObjects();
        if(objectsInGroup.length == 2){

            var data = [];

            var exist = false;
            var startIndex = (type == PATHPOINT_CONNECT_LEFT ? 0 : 1);
            var endIndex = (type == PATHPOINT_CONNECT_LEFT ? 1 : 0);
            for(var i = 0; i < pathLines.length; i ++){
                if(pathLines[i].startObject == objectsInGroup[startIndex] 
                    && pathLines[i].endObject == objectsInGroup[endIndex]){
                    exist = true;
                break;
            }
            if(pathLines[i].endObject == objectsInGroup[startIndex] 
                && pathLines[i].startObject == objectsInGroup[endIndex]){
                    exist = true;
                    break;
                }
            }

            if(!exist){
                var pointLine = {
                    startObject: objectsInGroup[startIndex], 
                    endObject: objectsInGroup[endIndex],
                    type: type == PATHPOINT_CONNECT_BOTH ? 0 : 1,
                    line: null,
                    triangle: null
                }

                var path = new Path(pointLine);

                data.push(path.getData());

                var request = {
                    action: "addpath",
                    data: data
                }

                postAjaxJsonRequest(
                    URL_SENDDATA, 
                    request, 
                    function (obj) {
                        if(obj.error != 0){
                            $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                return;
                            });
                        }else{
                            if(obj.items){
                                request.data[0].id = obj.items[0].id;
                                parent.sendmsg(JSON.stringify(request));
                            }
                        }
                    },
                    printAjaxResult
                );

                /*
                pathLines.push({
                    startObject: objectsInGroup[startIndex], 
                    endObject: objectsInGroup[endIndex],
                    type: type == PATHPOINT_CONNECT_BOTH ? 0 : 1,
                    line: null,
                    triangle: null
                });

                var startObject = pathLines[pathLines.length - 1].startObject;
                var endObject = pathLines[pathLines.length - 1].endObject;

                canvas.deactivateAll();

                repaintPathLine(pathLines[pathLines.length - 1]);

                var objectList = new Array();

                objectsInGroup.forEach(function (object) {
                    object.set({
                        hasControls: true
                    });
                    objectList.push(object);
                });

                var objs = objectList.map(function (o) {
                    return o.set('active', true);
                });

                var selGroup = new fabric.Group(objs, {
                    originX: 'center',
                    originY: 'center'
                });

                canvas.setActiveGroup(selGroup.setCoords());*/
            }
            //canvas.renderAll();
        }
    }
}

function removePathLineByObject(obj){

    var data = [];

    for(var i = 0; i < pathLines.length; i ++){
        if(pathLines[i].startObject == obj || pathLines[i].endObject == obj){
            if(pathLines[i].id){
                data.push(pathLines[i].id);
            }
        }
    }

    if(data.length > 0){
        var request = {
            action: "removepath",
            data: data
        }
        
        postAjaxJsonRequest(
            URL_SENDDATA, 
            request, 
            function (obj) {
                if(obj.error != 0){
                    $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                        return;
                    });
                }else{
                    /*if(pathLines[i].line){
                        canvas.remove(pathLines[i].line);
                        canvas.remove(pathLines[i].triangle);
                    }
                    pathLines.splice(i, 1);*/
                    parent.sendmsg(JSON.stringify(request));
                }
            },
            printAjaxResult
        );
    }
}

function removePathLineByObjectId(obj, id){
    for(var i = 0; i < pathLines.length; i ++){
        if(pathLines[i].startObject.id == id || pathLines[i].endObject.id == id){
            if(pathLines[i].line){
                canvas.remove(pathLines[i].line);
                canvas.remove(pathLines[i].triangle);
            }
            pathLines.splice(i, 1);
            disconnectPathPoint(obj);
        }
    }
}

function disconnectPathPoint(){

    var activeObject = canvas.getActiveObject();
    var activeGroup = canvas.getActiveGroup();

    var data = [];

    if (activeGroup) {
        var objectsInGroup = activeGroup.getObjects();
        if(objectsInGroup.length == 2){
            for(var i = 0; i < pathLines.length; i ++){
                if((pathLines[i].startObject == objectsInGroup[0] && pathLines[i].endObject == objectsInGroup[1]) || 
                    (pathLines[i].startObject == objectsInGroup[1] && pathLines[i].endObject == objectsInGroup[0])){
                    if(pathLines[i].id){
                        data.push({
                            id: pathLines[i].id
                        });
                    }
                    break;
                }
            }

            if(data.length > 0){
                var request = {
                    action: "removepath",
                    data: data
                }
                
                postAjaxJsonRequest(
                    URL_SENDDATA, 
                    request, 
                    function (obj) {
                        if(obj.error != 0){
                            $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                return;
                            });
                        }else{
                            parent.sendmsg(JSON.stringify(request));
                        }
                    },
                    printAjaxResult
                );
            }
        }
    }
    else if (activeObject) {
        removePathLineByObject(activeObject);
    }
}

//删除所选的路径节点
function removePathPoint() {
    var activeObject = canvas.getActiveObject();
    var activeGroup = canvas.getActiveGroup();
    if (activeGroup) {
        $.messager.confirm('确认','删除是不可恢复的，你确认要删除选定路径节点吗？',function(res) {
            if(res) {
                var data = [];

                var objectsInGroup = activeGroup.getObjects();
                canvas.discardActiveGroup().renderAll();
                objectsInGroup.forEach(function (object) {
                    if(object.id){
                        data.push({
                            id: object.id
                        });
                    }
                });

                var request = {
                    action: "removepathpoint",
                    data: data
                }
                
                if(data.length > 0){
                    postAjaxJsonRequest(
                        URL_SENDDATA, 
                        request, 
                        function (obj) {
                            if(obj.error != 0){
                                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                    return;
                                });
                            }else{
                                parent.sendmsg(JSON.stringify(request));
                            }
                        },
                        printAjaxResult
                        );
                }
            }
        });
    }
    else if (activeObject && activeObject.id) {
        $.messager.confirm('确认','删除是不可恢复的，你确认要删除选定路径节点吗？',function(res) {
            if(res) {

                var data = [];

                data.push({
                    id: activeObject.id
                });

                var request = {
                    action: "removepathpoint",
                    data: data
                }

                postAjaxJsonRequest(
                    URL_SENDDATA, 
                    request, 
                    function (obj) {
                        if(obj.error != 0){
                            $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                return;
                            });
                        }else{
                            parent.sendmsg(JSON.stringify(request));
                        }
                    },
                    printAjaxResult
                    );
            }
        });
    }
}

function setPathPoint() {

}

//增加路径节点
function addPathPoint(x, y) {
    if(drawMode == DRAW_MODE_SET_EDIT && x >= 0 && y >= 0){

        var clone = fabric.util.object.clone(nodeObj);
        var width = nodeObj.width;
        var height = nodeObj.height;
        var scale = Math.min(svgSize / width, svgSize / height);
        clone.set({
            left: x,
            top: y,
            scaleX: canvasScale * scale,
            scaleY: canvasScale * scale,
            deviation: 0.1,
            objType: 'pathpoint'
        });

        var pathPoint = new PathPoint(clone);

        var data = [];

        data.push(pathPoint.getData());

        var request = {
            action: "addpathpoint",
            data: data
        }

        postAjaxJsonRequest(
            URL_SENDDATA, 
            request, 
            function (obj) {
                if(obj.error != 0){
                    $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                        return;
                    });
                }else{
                    if(obj.items){
                        request.data[0].id = obj.items[0].id;
                        parent.sendmsg(JSON.stringify(request));
                    }
                }
            },
            printAjaxResult
        );
    }
}

function findPathPointInCanvas(id){
    var objects = canvas.getObjects("path-group");
    
    for(var i = 0; i < objects.length; i ++){
        if(objects[i].objType && objects[i].objType == "pathpoint"){
            if(objects[i].id == id){
                return objects[i];
            }
        }
    }
    return null;
}

function notifyChanges(obj){
    console.log(obj);
    switch(obj.action){
        case 'addpathpoint':
        var pix = posToPix(obj.data[0].pos_x, obj.data[0].pos_y);
        var angle = directionToAngle(obj.data[0].pos_direct);
        var clone = fabric.util.object.clone(nodeObj);
        var width = nodeObj.width;
        var height = nodeObj.height;
        var scale = Math.min(svgSize / width, svgSize / height);
        clone.set({
            id: obj.data[0].id,
            code: obj.data[0].code,
            name: obj.data[0].name,
            deviation: obj.data[0].deviation,
            left: canvasScale * pix.x,
            top: canvasScale * pix.y,
            angle: angle,
            scaleX: canvasScale * scale,
            scaleY: canvasScale * scale,
            objType: 'pathpoint',
            //selectable: (drawMode == DRAW_MODE_SET_EDIT) ? true : false
        });
        canvas.add(clone);
        canvas.renderAll();
        break;
        case 'removepathpoint':
        canvas.deactivateAll();

        obj.data.forEach(function (object) {
            if(object.id){
                var objects = canvas.getObjects("path-group");
                objects.forEach(function(pathPointObj){
                    if(pathPointObj.objType && pathPointObj.objType == "pathpoint" && pathPointObj.id == object.id){
                        removePathLineByObjectId(pathPointObj, object.id);
                        canvas.remove(pathPointObj);
                    }
                });
            }
        });
        canvas.renderAll();
        break;
        case 'setpathpoint':
        var activeObject = canvas.getActiveObject();
        var activeGroup = canvas.getActiveGroup();

        canvas.deactivateAll();

        for(var i = 0; i < obj.data.length; i ++){
            var pix = posToPix(obj.data[i].pos_x, obj.data[i].pos_y);
            var angle = directionToAngle(obj.data[i].pos_direct);
            var width = nodeObj.width;
            var height = nodeObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);

            var objects = canvas.getObjects("path-group");
            objects.forEach(function(pathPointObj){
                if(pathPointObj.objType && pathPointObj.objType == "pathpoint" && pathPointObj.id == obj.data[i].id){
                    pathPointObj.set({
                        code: obj.data[i].code,
                        name: obj.data[i].name,
                        deviation: obj.data[i].deviation,
                        left: canvasScale * pix.x,
                        top: canvasScale * pix.y,
                        angle: angle,
                        scaleX: canvasScale * scale,
                        scaleY: canvasScale * scale,
                        //selectable: (drawMode == DRAW_MODE_SET_EDIT) ? true : false
                    }).setCoords();
                }
            });

        }

        pathLines.forEach(function(obj){
            repaintPathLine(obj);
        });

        if(activeObject){
            canvas.setActiveObject(activeObject.setCoords());
        }

        if(activeGroup){
            var objectList = new Array();

            var objectsInGroup = activeGroup.getObjects();

            objectsInGroup.forEach(function (object) {
                object.set({
                    hasControls: true
                });
                objectList.push(object);
            });

            var objs = objectList.map(function (o) {
                return o.set('active', true);
            });

            var selGroup = new fabric.Group(objs, {
                originX: 'center',
                originY: 'center'
            });

            canvas.setActiveGroup(selGroup.setCoords());

        }
        canvas.renderAll();
        break;
        case 'addpath':
        var activeObject = canvas.getActiveObject();
        var activeGroup = canvas.getActiveGroup();

        canvas.deactivateAll();

        obj.data.forEach(function (object) {
            if(object.id){
                var startObject = findPathPointInCanvas(object.start_point);
                var endObject = findPathPointInCanvas(object.end_point);
                if(startObject && endObject){
                    pathLines.push({
                        id: object.id,
                        startObject: startObject, 
                        endObject: endObject,
                        type: object.direction,
                        line: null,
                        triangle: null
                    });
                    repaintPathLine(pathLines[pathLines.length - 1]);
                }
            }
        });

        if(activeObject){
            canvas.setActiveObject(activeObject.setCoords());
        }

        if(activeGroup){
            var objectList = new Array();

            var objectsInGroup = activeGroup.getObjects();

            objectsInGroup.forEach(function (object) {
                object.set({
                    hasControls: true
                });
                objectList.push(object);
            });

            var objs = objectList.map(function (o) {
                return o.set('active', true);
            });

            var selGroup = new fabric.Group(objs, {
                originX: 'center',
                originY: 'center'
            });

            canvas.setActiveGroup(selGroup.setCoords());

        }
        canvas.renderAll();
        break
        case 'removepath':
        obj.data.forEach(function (object) {
            if(object.id){
                for(var i = 0; i < pathLines.length; i ++){
                    if(pathLines[i].id == object.id){
                        if(pathLines[i].line){
                            canvas.remove(pathLines[i].line);
                            canvas.remove(pathLines[i].triangle);
                        }
                        pathLines.splice(i, 1);
                    }
                }
                canvas.renderAll();
            }
        });
        break;
        case 'setpath':
        break;
        case 'sendctrl':
            switch(obj.data){
                /*case CTRL_CODE_ROBOT_FORWARD:
                case CTRL_CODE_ROBOT_TURNLEFT:
                case CTRL_CODE_ROBOT_BACKWARD:
                case CTRL_CODE_ROBOT_TURNRIGHT:*/
                case CTRL_CODE_ROBOT_KEEPSTOP:
                    $('#stop_sb').switchbutton('check');
                    $('#forward_btn').linkbutton('disable');
                    $('#left_btn').linkbutton('disable');
                    $('#backward_btn').linkbutton('disable');
                    $('#right_btn').linkbutton('disable');
                    $('#rotate_btn').linkbutton('disable');
                    $('#initto_btn').linkbutton('disable');
                    $('#moveto_btn').linkbutton('disable');
                break;
                case CTRL_CODE_ROBOT_STOP:
                    $('#stop_sb').switchbutton('uncheck');
                    $('#forward_btn').linkbutton('enable');
                    $('#left_btn').linkbutton('enable');
                    $('#backward_btn').linkbutton('enable');
                    $('#right_btn').linkbutton('enable');
                    $('#rotate_btn').linkbutton('enable');
                    $('#initto_btn').linkbutton('enable');
                    $('#moveto_btn').linkbutton('enable');
                break;
                default:
                break;
            }
        break;
        default:
        break;
    }
}

function initCanvas(){

    canvas = new fabric.Canvas('map_canvas', {
        allowTouchScrolling: true,
        renderOnAddRemove: false,
        enableRetinaScaling: true,
        selection: false
    });

    fabric.Object.prototype.set({
        padding: 6,
        transparentCorners: false,
        borderColor: '#999999',
        cornerColor: '#999999',
        cornerSize: 8
    });

    //指定节点类型
    fabric.Object.prototype.objType = "";
    //指定节点ID|英文标识|中文名称
    fabric.Object.prototype.id = null;
    fabric.Object.prototype.code = null;
    fabric.Object.prototype.name = null;
    fabric.Object.prototype.deviation = null;


    fabric.Group.prototype.set({
        hasControls: false,
        hasRotatingPoint: false
    });
    


    fabric.Image.fromURL(path + 'map/' + mapName + '.jpg', function(oImg) {

        bgImg = oImg;

        bgImg.scale(canvasScale);

        mapWidth = bgImg.getWidth();
        mapHeight = bgImg.getHeight();

        canvas.setBackgroundImage(bgImg);

        canvas.setWidth(mapWidth);
        canvas.setHeight(mapHeight);

        var ruler = 100;
        var stroke = "#000000";

        gridObj = new fabric.Group();

        for(var i = ruler; i < mapWidth;){
            var line = new fabric.Line([0, 0, 0, mapHeight], {
                left: i,
                top: 0,
                selectable: false,
                strokeWidth: 0.5,
                stroke: stroke,
                opacity: 0.3
            });
            gridObj.add(line);
            if(i % (2 * ruler) == 0){
                var text = new fabric.Text(i * mapResolution + "", {
                    left: i,
                    top: 5,
                    selectable: false,
                    originX: 'center', 
                    originY: 'center',
                    fontSize: 12,
                    fill: stroke,
                    opacity: 0.3
                });
                gridObj.add(text);
            }
            i += ruler;
        }

        for(var i = ruler; i < mapHeight;){
            var line = new fabric.Line([0, 0, mapWidth, 0], {
                left: 0,
                top: i,
                selectable: false,
                strokeWidth: 0.5,
                stroke: stroke,
                opacity: 0.3
            });
            gridObj.add(line);
            if(i % (2 * ruler) == 0){
                var text = new fabric.Text(i * mapResolution + "", {
                    left: 0,
                    top: i,
                    selectable: false,
                    originX: 'left', 
                    originY: 'center',
                    fontSize: 12,
                    fill: stroke,
                    opacity: 0.3
                });
                gridObj.add(text);
            }
            i += ruler;
        }

        canvas.add(gridObj);

        //加载路径节点图标
        fabric.loadSVGFromURL(nodeSrc, function (objects, options) {
            nodeObj = fabric.util.groupSVGElements(objects, options);
            var width = nodeObj.width;
            var height = nodeObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            nodeObj.set({
                left: 200, 
                top: 200, 
                selectable: true,
                hoverCursor: 'pointer',
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.6,
                angle: 0});
            nodeObj.setControlsVisibility({
                mt: false, 
                mb: false, 
                ml: false, 
                mr: false, 
                bl: false,
                br: false, 
                tl: false, 
                tr: false,
                mtr: true
            });
            //canvas.add(nodeObj);

            getPathPoint();

            //canvas.renderAll();
        });

        //加载目标点图标
        fabric.loadSVGFromURL(arrowSrc, function (objects, options) {
            arrowObj = fabric.util.groupSVGElements(objects, options);
            var width = arrowObj.width;
            var height = arrowObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            arrowObj.set({ 
                left: -1000, 
                top: -1000, 
                selectable: false,
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.8,
                angle: 0});
            canvas.add(arrowObj);

            canvas.renderAll();
        });

        //加载机器人图标
        fabric.loadSVGFromURL(robotSrc, function (objects, options) {
            robotObj = fabric.util.groupSVGElements(objects, options);
            var width = robotObj.width;
            var height = robotObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            robotObj.set({ 
                left: -1000, 
                top: -1000, 
                selectable: false,
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.8,
                angle: 0});
            canvas.add(robotObj);

            canvas.renderAll();

            startAnimateRobot();
            //animate(robotObj, 3);

        });
        canvas.calcOffset();
    });

    /*function animate(obj, times) {
        var t = times;
        obj.setOpacity(0).animate({opacity: 1}, {
            duration: 500,
            onComplete: function(){
                if(t -- > 0){      
                    obj.setOpacity(1).animate({opacity: 0},{
                        duration: 500,
                        onComplete: function(){
                            animate(obj, -- t);
                        }
                    });
                }
            },
        });
    }

    (function render(){
        canvas.renderAll();
        fabric.util.requestAnimFrame(render);
    })();*/

    canvas.on({
        "object:selected":function(evt){
            if(evt.target && evt.target.objType && evt.target.objType == 'pathpoint'){
                updatePathPointProperty(evt.target.id, evt.target.code, evt.target.name, evt.target.left, evt.target.top, evt.target.angle, evt.target.deviation);
                
                if(drawMode == DRAW_MODE_SET_DIRECTION){

                    if($('#node_btn').linkbutton('options').selected){

                        arrowObj.set({ 
                            left: evt.target.left, 
                            top: evt.target.top, 
                            angle: evt.target.angle
                        });

                        updateTargetProperty(evt.target.left, evt.target.top, evt.target.angle);

                    }
                }
            }
        },
        "object:modified":function(evt){

            var activeObject = canvas.getActiveObject();

            if(activeObject && activeObject.id && evt.target && evt.target.objType && evt.target.id && activeObject.id == evt.target.id){
                updatePathPointProperty(activeObject.id, activeObject.code, activeObject.name, activeObject.left, activeObject.top, activeObject.angle, activeObject.deviation);
            }

            var data = [];

            if(evt.target && evt.target.id){
                var pathPoint = new PathPoint(evt.target);
                data.push(pathPoint.getData());

                var request = {
                    action: "setpathpoint",
                    data: data
                }

                postAjaxJsonRequest(
                    URL_SENDDATA, 
                    request, 
                    function (obj) {
                        if(obj.error != 0){
                            $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                return;
                            });
                        }else{
                            parent.sendmsg(JSON.stringify(request));
                        }
                    },
                    printAjaxResult
                    );
            }

            var repaintPathLines = false;
            var isGroup = false;

            if(evt.target && evt.target.objects){
                isGroup = true;

                canvas.deactivateAll();

                evt.target.objects.forEach(function(obj){
                    if(obj.objType == 'pathpoint'){
                        repaintPathLines = true;
                        if(obj.id){
                            var pathPoint = new PathPoint(obj);
                            data.push(pathPoint.getData());
                        }
                    }
                })

                var request = {
                    action: "setpathpoint",
                    data: data
                }

                postAjaxJsonRequest(
                    URL_SENDDATA, 
                    request, 
                    function (obj) {
                        if(obj.error != 0){
                            $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                                return;
                            });
                        }else{
                            parent.sendmsg(JSON.stringify(request));
                        }
                    },
                    printAjaxResult
                    );
                //canvas.deactivateAll();
            }

            if((evt.target && evt.target.objType && evt.target.objType == 'pathpoint') || repaintPathLines){
                pathLines.forEach(function(obj){
                    repaintPathLine(obj);
                });

                if(isGroup){
                    var objectList = new Array();

                    evt.target.objects.forEach(function (object) {
                        object.set({
                            hasControls: true
                        });
                        objectList.push(object);
                    });

                    var objs = objectList.map(function (o) {
                        return o.set('active', true);
                    });

                    var selGroup = new fabric.Group(objs, {
                        originX: 'center',
                        originY: 'center'
                    });

                    canvas.setActiveGroup(selGroup.setCoords());

                }

                canvas.renderAll();
            }
        },
        "object:moving":function(evt){
            if(drawMode == DRAW_MODE_SET_EDIT){
                var repaintPathLines = false;
                var isGroupSelect = false;

                if(evt.target && evt.target.objects){
                    isGroupSelect = true;
                    evt.target.objects.forEach(function(obj){
                        if(obj.objType == 'pathpoint'){
                            repaintPathLines = true;
                        }
                    })
                }

                if((evt.target && evt.target.objType && evt.target.objType == 'pathpoint') || repaintPathLines){
                    pathLines.forEach(function(obj){

                        if(obj.line){
                            canvas.remove(obj.line);
                            canvas.remove(obj.triangle);
                        }

                        if(!isGroupSelect){
                            //repaintPathLine(obj);
                            //canvas.renderAll();
                        }
                    });
                }
            }
        },
        "mouse:down":function(evt){
            dragmove = true;
            switch(drawMode){
                case DRAW_MODE_BROWSE:
                scrollX = evt.e.layerX;
                scrollY = evt.e.layerY;
                break;
                case DRAW_MODE_SET_DIRECTION:
                clickX = evt.e.layerX;
                clickY = evt.e.layerY;
                if(!$('#node_btn').linkbutton('options').selected){
                    updateArrow(clickX, clickY, -1, -1);
                }
                break;
                case DRAW_MODE_SET_EDIT:
                clickX = evt.e.layerX;
                clickY = evt.e.layerY;
                /*var newNodeObj = fabric.util.object.clone(nodeObj);
                newNodeObj.set({
                    left: clickX, 
                    top: clickY, 
                    selectable: true
                });
                canvas.add(newNodeObj);*/
                break;
                default:
                break;
            }
        },
        "mouse:move":function(evt){
            if(dragmove) {
                switch(drawMode){
                    case DRAW_MODE_BROWSE:
                    break;
                    case DRAW_MODE_SET_DIRECTION:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    if(!$('#node_btn').linkbutton('options').selected){
                        updateArrow(clickX, clickY, moveX, moveY);
                    }
                    break;
                    case DRAW_MODE_SET_EDIT:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    default:
                    break;
                }
            }
        },
        "mouse:up":function(evt){
            if(dragmove) {
                switch(drawMode){
                    case DRAW_MODE_BROWSE:
                    var map_div = $("#map_div");

                    map_div.scrollLeft(map_div.scrollLeft() - evt.e.layerX + scrollX);
                    map_div.scrollTop(map_div.scrollTop() - evt.e.layerY + scrollY);

                    scrollX = evt.e.layerX;
                    scrollY = evt.e.layerY;
                    break;
                    case DRAW_MODE_SET_DIRECTION:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    case DRAW_MODE_SET_EDIT:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    default:
                    break;
                }
                dragmove = false;
            }
        }
    });
}

$(document).ready(function(){

    $("#map_div").scroll(function() {
        canvas.calcOffset();
    });
    $("#map_div").resize(function() {
        canvas.calcOffset();
    });

    $('#browse_btn').bind('click', function(){setDrawMode(DRAW_MODE_BROWSE);});
    $('#call_btn').bind('click', function(){setDrawMode(DRAW_MODE_SET_DIRECTION);});
    $('#edit_btn').bind('click', function(){setDrawMode(DRAW_MODE_SET_EDIT);});

    $('#refresh_btn').bind('click', reloadMap);
    $('#autorefresh_btn').bind('click', function(){
        if($('#autorefresh_btn').linkbutton('options').selected){
            startRefreshingMap();
        }else{
            stopRefreshingMap();
        }
    });
    $('#navwin_btn').bind('click', initNavWin);
    $('#zoomin_btn').bind('click', zoomIn);
    $('#zoomout_btn').bind('click', zoomOut);
    $('#grid_btn').bind('click', function(){
        if(gridObj){
            gridObj.set({
                visible: $('#grid_btn').linkbutton('options').selected
            });
        }
    });

    $('#addpathpoint_btn').bind('click', function(){addPathPoint(clickX, clickY);});
    $('#removepathpoint_btn').bind('click', removePathPoint);
    $('#connectpathpoint_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_BOTH);});
    $('#connectpathpointleft_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_LEFT);});
    $('#connectpathpointright_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_RIGHT);});
    $('#disconnectpathpoint_btn').bind('click', function(){disconnectPathPoint();});
    //$('#savepathpoint_btn').bind('click', savePathPoint);
    $('#lock_btn').bind('click', lockPathPoints);
    $('#unlock_btn').bind('click', unlockPathPoints);
    $('#robot_btn').bind('click', cloneRobotPosition);

    $('#mission_btn').bind('click', sendMission);

    $('#forward_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_FORWARD);});
    $('#forward_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#left_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_TURNLEFT);});
    $('#left_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#backward_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_BACKWARD);});
    $('#backward_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#right_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_TURNRIGHT);});
    $('#right_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});

    $('#rotate_btn').bind('click', setDirection);

    $('#initto_btn').bind('click', function(){sendLocationCtrl(CTRL_CODE_ROBOT_INIT_MOVETO);});
    $('#moveto_btn').bind('click', function(){sendLocationCtrl(CTRL_CODE_ROBOT_MOVETO);});

    $("#stop_sb").switchbutton({
        onChange: function(checked){
            if(checked){
                startStopping();
            }else{
                stopMoving();
            }
        }
    });

    $('#browse_btn').tooltip({position: 'bottom',content: '<span style="color:#666">浏览模式</span>'});
    $('#call_btn').tooltip({position: 'bottom',content: '<span style="color:#666">控制模式</span>'});
    $('#edit_btn').tooltip({position: 'bottom',content: '<span style="color:#666">编辑模式</span>'});
    $('#autorefresh_btn').tooltip({position: 'bottom',content: '<span style="color:#666">自动刷新地图</span>'});
    $('#refresh_btn').tooltip({position: 'bottom',content: '<span style="color:#666">手动刷新地图</span>'});
    $('#navwin_btn').tooltip({position: 'bottom',content: '<span style="color:#666">缩略图</span>'});
    $('#grid_btn').tooltip({position: 'bottom',content: '<span style="color:#666">显示网格</span>'});
    $('#zoomin_btn').tooltip({position: 'bottom',content: '<span style="color:#666">放大</span>'});
    $('#zoomout_btn').tooltip({position: 'bottom',content: '<span style="color:#666">缩小</span>'});

    $('#addpathpoint_btn').tooltip({position: 'bottom',content: '<span style="color:#666">增加路径节点</span>'});
    $('#removepathpoint_btn').tooltip({position: 'bottom',content: '<span style="color:#666">删除路径节点</span>'});
    $('#connectpathpoint_btn').tooltip({position: 'bottom',content: '<span style="color:#666">双向连接</span>'});
    $('#connectpathpointleft_btn').tooltip({position: 'bottom',content: '<span style="color:#666">单项连接(A-B)</span>'});
    $('#connectpathpointright_btn').tooltip({position: 'bottom',content: '<span style="color:#666">单项连接(B-A)</span>'});
    $('#disconnectpathpoint_btn').tooltip({position: 'bottom',content: '<span style="color:#666">删除连接</span>'});
    $('#mission_btn').tooltip({position: 'bottom',content: '<span style="color:#666">发送巡检任务(测试)</span>'});
    $('#lock_btn').tooltip({position: 'bottom',content: '<span style="color:#666">锁定路径节点</span>'});
    $('#unlock_btn').tooltip({position: 'bottom',content: '<span style="color:#666">解锁路径节点</span>'});
    $('#robot_btn').tooltip({position: 'bottom',content: '<span style="color:#666">将路径节点位置设为机器人位置</span>'});
    $('#node_btn').tooltip({position: 'bottom',content: '<span style="color:#666">目标点吸附到路径节点</span>'});

    $('#initto_btn').tooltip({position: 'right',content: '<span style="color:#666">初始状态定位</span>'});
    $('#initto_btn').tooltip({position: 'right',content: '<span style="color:#666">初始状态定位</span>'});
    $('#moveto_btn').tooltip({position: 'right',content: '<span style="color:#666">移动至目标位置</span>'});
    $('#rotate_btn').tooltip({position: 'right',content: '<span style="color:#666">按设定角度转向</span>'});



    $("#zoom_cb").combobox({
        editable : false,
        data:[{
            text: '60',
            value: 60
        },{
            text: '80',
            value: 80
        },{
            text: '100',
            value: 100
        },{
            text: '110',
            value: 110
        },{
            text: '120',
            value: 120
        },{
            text: '130',
            value: 130
        },{
            text: '150',
            value: 150
        },{
            text: '180',
            value: 180
        },{
            text: '200',
            value: 200
        }],
        onChange: function(newValue, oldValue){
            zoomTo(newValue / 100);
        }
    });

    $("#zoom_cb").combobox('setValue', 100);

    var rowsMap = new Array();
    rowsMap.push({
        name: "X坐标",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsMap.push({
        name: "Y坐标",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsMap.push({
        name: "角度",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            min: 0,
            max: 360,
            precision: 10
        }}
    });
    rowsMap.push({
        name: "X坐标",
        group: "机器人位置",
        value: robotX,
        editor: ''
    });
    rowsMap.push({
        name: "Y坐标",
        group: "机器人位置",
        value: robotY,
        editor: ''
    });
    rowsMap.push({
        name: "角度",
        group: "机器人位置",
        value: robotAngle,
        editor: ''
    });
    rowsMap.push({
        name: "聚集度",
        group: "机器人位置",
        value: robotAccuracy,
        editor: ''
    });

    rowsMap.push({
        name: "比例(米/像素)",
        group: "地图偏移量",
        value: mapResolution,
        editor: ''
    });

    rowsMap.push({
        name: "起始X坐标",
        group: "地图偏移量",
        value: mapOriginX,
        editor: ''
    });

    rowsMap.push({
        name: "起始Y坐标",
        group: "地图偏移量",
        value: mapOriginY,
        editor: ''
    });

    $('#map_pg').propertygrid({
        width: 'auto',
        height: 'auto',
        showGroup: true,
        scrollbarSize: 0,
        columns: [[
        { field: 'name', title: '属性', width: 100, resizable: true },
        { field: 'value', title: '值', width: 100, resizable: true }
        ]],
        onAfterEdit: function(index, row, changes){
            if(changes.value){
                var data = $('#map_pg').propertygrid('getData');

                var x = Math.round((data.rows[0].value - mapOriginX) / mapResolution);
                var y = - Math.round((data.rows[1].value - mapOriginY - mapHeight * mapResolution) / mapResolution);
                var angle = (data.rows[2].value + 90) > 360 ? data.rows[2].value + 90 - 360 : data.rows[2].value + 90;

                arrowObj.set({ left: Math.round(x * canvasScale), top: Math.round(y * canvasScale), angle: angle});
                canvas.fire('object:modified', {target: arrowObj});
                canvas.renderAll();
            }
        }
    });

    rowsMap.forEach(function(row){
        $('#map_pg').propertygrid('appendRow', row);
    });

    rowsEdit = new Array();
    rowsEdit.push({
        name: "ID",
        editor: ''
    });
    rowsEdit.push({
        name: "英文标识",
        editor: 'text'
    });
    rowsEdit.push({
        name: "中文名称",
        editor: 'text'
    });
    rowsEdit.push({
        name: "X坐标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsEdit.push({
        name: "Y坐标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsEdit.push({
        name: "角度",
        value: 0,
        editor: {type:'floatbox',options:{
            min: 0,
            max: 360,
            precision: 10
        }}
    });
    rowsEdit.push({
        name: "允许偏差+-范围",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });

    $('#edit_pg').propertygrid({
        width: 'auto',
        height: 'auto',
        showGroup: false,
        scrollbarSize: 0,
        columns: [[
        { field: 'name', title: '属性', width: 100, resizable: true },
        { field: 'value', title: '值', width: 100, resizable: true }
        ]],
        onAfterEdit: function(index, row, changes){
            if(changes.value){
                var data = $('#edit_pg').propertygrid('getData');

                var objects = canvas.getObjects("path-group");
                objects.forEach(function(obj){

                    if(obj.objType && obj.objType == "pathpoint" && obj.id == parseInt(data.rows[0].value)){

                        var pix = posToPix(data.rows[3].value, data.rows[4].value);

                        var x = pix.x;
                        var y = pix.y;
                        var angle = directionToAngle(data.rows[5].value);

                        var activeObject = canvas.getActiveObject();

                        canvas.deactivateAll();

                        obj.set({
                            left: Math.round(x * canvasScale),
                            top: Math.round(y * canvasScale),
                            angle: angle,
                            code: data.rows[1].value,
                            name: data.rows[2].value,
                            deviation: data.rows[6].deviation
                        });

                        canvas.fire('object:modified', {target: obj});
                        canvas.renderAll();

                        pathLines.forEach(function(obj){
                            repaintPathLine(obj);
                        });

                        if(activeObject){
                            canvas.setActiveObject(activeObject.setCoords());
                        }
                    }
                });
            }
        }
    });

    rowsEdit.forEach(function(row){
        $('#edit_pg').propertygrid('appendRow', row);
    });

    loadMapSettings();

    setDrawMode(DRAW_MODE_BROWSE);

});