var SCALE_FACTOR                    = 1.1;
var CANVAS_MAX_AREA                 = 268435456;


var clickX = -1;
var clickY = -1;
var moveX = -1;
var moveY = -1;
var scrollX = -1;
var scrollY = -1;
var arrowX = -1000;
var arrowY = -1000;
var robotX = -1000;
var robotY = -1000;
var robotAngle = 0;
var path = "../";
var dragmove = false;
var arrowSrc = path + "images/svg/arrow_green.svg";
var arrowObj = null;
var robotSrc = path + "images/svg/arrow_blue.svg";
var robotObj = null;
var nodeSrc = path + "images/svg/target.svg";
var nodeObj = null;

var URL_SENDCTRL = path + "php/sendctrl.php";
var URL_SENDDATA = path + 'php/client.php';

var isBtnPressed = false;
var isKeyDown = false;
var canvas;
var timerCmd;                           //任务持续发送定时器
var frequenceCmd = 200;                 //任务持续发送频率
var timerMap;                           //地图刷新定时器
var frequenceMap = 3000;                //地图刷新频率
var timerAnimateRobot;                  //机器人图标闪烁定时器
var frequenceAnimateRobot = 800;        //机器人图标闪烁频率
var bgImg;
var dragmove = false;
var drawMode = DRAW_MODE_BROWSE;
var svgSize = 30;
var mapName = "map";
var pathLines = new Array();



function initNavWin() {
    var img = $("#graph-nav");
    var scaleRate = 298 / canvas.getWidth();
    var dataURL = canvas.toDataURL({
        format: 'jpeg',
        quality: 1,
        multiplier: scaleRate
    });
    img.attr("src", dataURL);
    img.unbind("click");
    img.bind("click", function (event) {
        var width = $(this)[0].clientWidth;
        var height = $(this)[0].clientHeight;
        var map_div = $("#map_div");
        var navX = event.offsetX;
        var navY = event.offsetY;
        map_div.scrollLeft((navX / width) * canvas.getWidth() - map_div[0].clientWidth / 2);
        map_div.scrollTop((navY / height) * canvas.getHeight() - map_div[0].clientHeight / 2);
    });
    $('#map_win').window('open');
}

function updateTargetProperty(x, y, angle){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[0].value = (x / canvasScale) * mapResolution + mapOriginX;
    rows[1].value = mapHeight * mapResolution - (y / canvasScale) * mapResolution + mapOriginY;
    rows[2].value = angle;

    $('#map_pg').propertygrid('refreshRow', 0);
    $('#map_pg').propertygrid('refreshRow', 1);
    $('#map_pg').propertygrid('refreshRow', 2);
}

function updateMapProperty(){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[6].value = mapResolution;
    rows[7].value = mapOriginX;
    rows[8].value = mapOriginY;

    $('#map_pg').propertygrid('refreshRow', 6);
    $('#map_pg').propertygrid('refreshRow', 7);
    $('#map_pg').propertygrid('refreshRow', 8);
}

function updateRobotProperty(posx, posy, direction){
    var rows = $('#map_pg').propertygrid('getRows');

    rows[3].value = posx;
    rows[4].value = posy;
    rows[5].value = direction;

    $('#map_pg').propertygrid('refreshRow', 3);
    $('#map_pg').propertygrid('refreshRow', 4);
    $('#map_pg').propertygrid('refreshRow', 5);
}

function updatePathPointProperty(id, code, name, x, y, angle){
    var rows = $('#edit_pg').propertygrid('getRows');

    rows[0].value = id;
    rows[1].value = code;
    rows[2].value = name;
    rows[3].value = pixToPos(x / canvasScale, y / canvasScale).posx;
    rows[4].value = pixToPos(x / canvasScale, y / canvasScale).posy;
    rows[5].value = angleToDirection(angle);

    $('#edit_pg').propertygrid('refreshRow', 0);
    $('#edit_pg').propertygrid('refreshRow', 1);
    $('#edit_pg').propertygrid('refreshRow', 2);
    $('#edit_pg').propertygrid('refreshRow', 3);
    $('#edit_pg').propertygrid('refreshRow', 4);
    $('#edit_pg').propertygrid('refreshRow', 5);
}

function updateRobotPosition(posx, posy, direction){
    robotX = Math.round((posx - mapOriginX) / mapResolution);
    robotY = - Math.round((posy - mapOriginY - mapHeight * mapResolution) / mapResolution);
    robotAngle = (direction + 90) > 360 ? direction + 90 - 360 : direction + 90;

    robotObj.set({ left: Math.round(robotX * canvasScale), top: Math.round(robotY * canvasScale), angle: robotAngle});
    canvas.fire('object:modified', {target: robotObj});
    canvas.renderAll();

    updateRobotProperty(posx, posy, direction);
}


var iopacity = 0.8;

function startAnimateRobot(){
    clearInterval(timerAnimateRobot);
    timerAnimateRobot =  self.setInterval(function(){
        robotObj.set({ opacity: iopacity});
        if(drawMode == DRAW_MODE_SET_EDIT){
            canvas.sendToBack(robotObj);
        }else{
            canvas.bringToFront(robotObj);
        }
        canvas.fire('object:modified', {target: robotObj});
        canvas.renderAll();
        if(iopacity == 0.2){
            iopacity = 0.8;
        }else{
            iopacity = 0.2;
        }
    },frequenceAnimateRobot);
}

function stopAnimateRobot(){
    clearInterval(timerAnimateRobot);
}

function startRefreshingMap(){
    clearInterval(timerMap);
    timerMap =  self.setInterval(function(){
        reloadMap();
    },frequenceMap);
}

function stopRefreshingMap(){
    clearInterval(timerMap);
}

function reloadMap(){

    $('#map_win').window('close');

    var date = new Date();
    var timestamp = date.getTime();

    fabric.Image.fromURL('map/' + mapName + '.jpg?timestamp=' + timestamp, function(oImg) {

        bgImg = oImg;

        bgImg.scale(canvasScale);

        mapWidth = bgImg.getWidth();
        mapHeight = bgImg.getHeight();

        canvas.setBackgroundImage(bgImg);

        canvas.setWidth(mapWidth);
        canvas.setHeight(mapHeight);

        canvas.calcOffset();

        loadMapSettings();
    });
}

function setDrawMode(mode){
    switch(mode){
        case DRAW_MODE_BROWSE:
        if(canvas){canvas.selection = false;}

        $('#refresh_btn').show();
        $('#refresh_sb').switchbutton('enable');

        $('#initto_btn').hide();
        $('#moveto_btn').hide();

        $('#addpathpoint_btn').hide();
        $('#removepathpoint_btn').hide();
        $('#connectpathpoint_btn').hide();
        $('#connectpathpointleft_btn').hide();
        $('#connectpathpointright_btn').hide();
        $('#disconnectpathpoint_btn').hide();
        $('#savepathpoint_btn').hide();
        $('#lock_btn').hide();
        $('#unlock_btn').hide();
        $('#robot_btn').hide();

        //$('#layout').layout('collapse', 'west');
        //$('#layout').layout('collapse', 'east');

        enablePathPoints(false);
        hidePathPoints();

        break;
        case DRAW_MODE_SET_DIRECTION:
        if(canvas){canvas.selection = false;}

        $('#refresh_btn').hide();
        $('#refresh_sb').switchbutton('disable');

        $('#initto_btn').show();
        $('#moveto_btn').show();

        $('#addpathpoint_btn').hide();
        $('#removepathpoint_btn').hide();
        $('#connectpathpoint_btn').hide();
        $('#connectpathpointleft_btn').hide();
        $('#connectpathpointright_btn').hide();
        $('#disconnectpathpoint_btn').hide();
        $('#savepathpoint_btn').hide();
        $('#lock_btn').hide();
        $('#unlock_btn').hide();
        $('#robot_btn').hide();

        $('#layout').layout('expand', 'west');
        //$('#layout').layout('collapse', 'east');

        enablePathPoints(false);
        hidePathPoints();

        break;
        case DRAW_MODE_SET_EDIT:
        if(canvas){canvas.selection = true;}

        $('#refresh_btn').hide();
        $('#refresh_sb').switchbutton('disable');

        $('#initto_btn').hide();
        $('#moveto_btn').hide();

        $('#addpathpoint_btn').show();
        $('#removepathpoint_btn').show();
        $('#connectpathpoint_btn').show();
        $('#connectpathpointleft_btn').show();
        $('#connectpathpointright_btn').show();
        $('#disconnectpathpoint_btn').show();
        $('#savepathpoint_btn').show();
        $('#lock_btn').show();
        $('#unlock_btn').show();
        $('#robot_btn').show();

        //$('#layout').layout('collapse', 'west');
        $('#layout').layout('expand', 'east');

        enablePathPoints(true);
        showPathPoints();

        break;
        default:
        break;
    }
    drawMode = mode;
}

function startMoving(cmd){
    clearInterval(timerCmd);
    timerCmd =  self.setInterval(function(){
        sendMovingCtrl(cmd);
    },frequenceCmd);
}

function sendMovingCtrl(cmd){
    var speed = $("#rs_slider").slider("getValue");

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: cmd,
            speed: speed
        }, 
        printAjaxResult,
        printAjaxResult
    );
}

function sendLocationCtrl(cmd){

    var data = $('#map_pg').propertygrid('getData');

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: cmd,
            posx: data.rows[0].value,
            posy: data.rows[1].value,
            direction: data.rows[2].value
        }, 
        printAjaxResult,
        printAjaxResult
    );
}

function setDirection(){
    var direction = parseInt($('#angle_ns').val());
    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: CTRL_CODE_ROBOT_ROTATE,
            direction: direction
        }, 
        printAjaxResult,
        printAjaxResult
    );
}

function stopMoving(){
    clearInterval(timerCmd);

    postAjaxJsonRequest(
        URL_SENDCTRL, 
        {
            action: CTRL_CODE_ROBOT_STOP
        }, 
        printAjaxResult,
        printAjaxResult
    );
}

$(document).keydown(function(event){
    if(isKeyDown == false){
        switch(event.keyCode){
            case KEY_CODE_LEFT:
            startMoving(CTRL_CODE_ROBOT_TURNLEFT);
            break;
            case KEY_CODE_UP:
            startMoving(CTRL_CODE_ROBOT_FORWARD);
            break;
            case KEY_CODE_RIGHT:
            startMoving(CTRL_CODE_ROBOT_TURNRIGHT);
            break;
            case KEY_CODE_DOWN:
            startMoving(CTRL_CODE_ROBOT_BACKWARD);
            break;
            default:
            break;
        }
        isKeyDown = true;
    }
})

$(document).keyup(function(event){
    if(isKeyDown == true){
        switch(event.keyCode){
            case KEY_CODE_LEFT:
            case KEY_CODE_UP:
            case KEY_CODE_RIGHT:
            case KEY_CODE_DOWN:
            stopMoving();
            isKeyDown = false;
            break;
            default:
            break;
        }
    }
})


function onpress(cmd){
    isBtnPressed = true;
    switch(cmd){
        case CTRL_CODE_ROBOT_FORWARD:
        case CTRL_CODE_ROBOT_TURNLEFT:
        case CTRL_CODE_ROBOT_BACKWARD:
        case CTRL_CODE_ROBOT_TURNRIGHT:
        startMoving(cmd);
        break;
        default:
        break;
    }
}

function onrelease(cmd){

    if(isBtnPressed){
        isBtnPressed = false;
        switch(cmd){
            case CTRL_CODE_ROBOT_STOP:
            stopMoving();
            break;
            default:
            break;
        }
    }
}

function zoomIn() {
    if(canvas.getHeight() * SCALE_FACTOR * canvas.getWidth() * SCALE_FACTOR > CANVAS_MAX_AREA){
        alert("画布面积超出限制");
        return;
    }

    canvas.deactivateAll();

    canvasScale = canvasScale * SCALE_FACTOR;
    
    canvas.setHeight(canvas.getHeight() * SCALE_FACTOR);
    canvas.setWidth(canvas.getWidth() * SCALE_FACTOR);

    bgImg.scale(canvasScale);

    canvas.setBackgroundImage(bgImg);
    
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX,
        scaleY = objects[i].scaleY,
        left = objects[i].left,
        top = objects[i].top,
        tempScaleX = scaleX * SCALE_FACTOR,
        tempScaleY = scaleY * SCALE_FACTOR,
        tempLeft = left * SCALE_FACTOR,
        tempTop = top * SCALE_FACTOR;
        
        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;
        
        objects[i].setCoords();
    }

    canvas.renderAll();

    $("#zoom_cb").combobox('unselect', $("#zoom_cb").combobox('getValue'));

}

function zoomOut() {

    canvas.deactivateAll();
    
    canvasScale = canvasScale / SCALE_FACTOR;
    
    canvas.setHeight(canvas.getHeight() * (1 / SCALE_FACTOR));
    canvas.setWidth(canvas.getWidth() * (1 / SCALE_FACTOR));

    bgImg.scale(canvasScale);

    canvas.setBackgroundImage(bgImg);
    
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX,
        scaleY = objects[i].scaleY,
        left = objects[i].left,
        top = objects[i].top,
        tempScaleX = scaleX * (1 / SCALE_FACTOR),
        tempScaleY = scaleY * (1 / SCALE_FACTOR),
        tempLeft = left * (1 / SCALE_FACTOR),
        tempTop = top * (1 / SCALE_FACTOR);

        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;

        objects[i].setCoords();
    }
    
    canvas.renderAll();

    $("#zoom_cb").combobox('unselect', $("#zoom_cb").combobox('getValue'));
}

function zoomTo(factor) {

    if(canvas == null || !factor){
        return;
    }

    canvas.deactivateAll();

    var newFactor = factor / canvasScale;

    if(canvas.getHeight() * newFactor * canvas.getWidth() * newFactor > CANVAS_MAX_AREA){
        alert("画布面积超出限制");
        return;
    }

    canvasScale = canvasScale * newFactor;
    
    canvas.setHeight(canvas.getHeight() * newFactor);
    canvas.setWidth(canvas.getWidth() * newFactor);

    bgImg.scale(canvasScale);

    canvas.setBackgroundImage(bgImg);
    
    var objects = canvas.getObjects();
    for (var i in objects) {
        var scaleX = objects[i].scaleX,
        scaleY = objects[i].scaleY,
        left = objects[i].left,
        top = objects[i].top,
        tempScaleX = scaleX * newFactor,
        tempScaleY = scaleY * newFactor,
        tempLeft = left * newFactor,
        tempTop = top * newFactor;
        
        objects[i].scaleX = tempScaleX;
        objects[i].scaleY = tempScaleY;
        objects[i].left = tempLeft;
        objects[i].top = tempTop;
        
        objects[i].setCoords();
    }

    canvas.renderAll();
}

function initPropertygrid(){
    var rowsMap = new Array();
    rowsMap.push({
        name: "X坐标",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsMap.push({
        name: "Y坐标",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsMap.push({
        name: "角度",
        group: "目标",
        value: 0,
        editor: {type:'floatbox',options:{
            min: 0,
            max: 360,
            precision: 10
        }}
    });
    rowsMap.push({
        name: "X坐标",
        group: "机器人位置",
        value: robotX,
        editor: ''
    });
    rowsMap.push({
        name: "Y坐标",
        group: "机器人位置",
        value: robotY,
        editor: ''
    });
    rowsMap.push({
        name: "角度",
        group: "机器人位置",
        value: robotAngle,
        editor: ''
    });

    rowsMap.push({
        name: "比例(米/像素)",
        group: "地图偏移量",
        value: mapResolution,
        editor: ''
    });

    rowsMap.push({
        name: "起始X坐标",
        group: "地图偏移量",
        value: mapOriginX,
        editor: ''
    });

    rowsMap.push({
        name: "起始Y坐标",
        group: "地图偏移量",
        value: mapOriginY,
        editor: ''
    });

    $('#map_pg').propertygrid('loadData', rowsMap);


    rowsEdit = new Array();
    rowsEdit.push({
        name: "ID",
        group: "路径节点",
        editor: ''
    });
    rowsEdit.push({
        name: "英文标识",
        group: "路径节点",
        editor: 'text'
    });
    rowsEdit.push({
        name: "中文名称",
        group: "路径节点",
        editor: 'text'
    });
    rowsEdit.push({
        name: "X坐标",
        group: "路径节点",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsEdit.push({
        name: "Y坐标",
        group: "路径节点",
        value: 0,
        editor: {type:'floatbox',options:{
            precision: 10
        }}
    });
    rowsEdit.push({
        name: "角度",
        group: "路径节点",
        value: 0,
        editor: {type:'floatbox',options:{
            min: 0,
            max: 360,
            precision: 10
        }}
    });

    $('#edit_pg').propertygrid('loadData', rowsEdit);

}

function loadMapSettings(){
    $.ajax({
        url: path + 'map/' + mapName + '.yaml',
        type: "GET",
        dataType: 'text',
        success: function (txt) {
            console.log(txt);
            var strs = new Array();
            strs = txt.split("\n");
            for(var i = 0; i < strs.length; i ++){
                if(strs[i].split(":")[0].trim() == "resolution"){
                    mapResolution = parseFloat(strs[i].split(":")[1]);
                }
                if(strs[i].split(":")[0].trim() == "origin"){
                    var origin = strs[i].split(":")[1].trim();
                    origin = origin.slice(1,origin.length - 1);
                    mapOriginX = parseFloat(origin.split(",")[0]);
                    mapOriginY = parseFloat(origin.split(",")[1]);
                }
            }

            var data = $('#map_pg').propertygrid('getData');
            if(data.total == 0){
                initPropertygrid();
            }else{
                updateMapProperty();
            }

            initCanvas();
        }
    });
}

function updateArrow(x1, y1, x2, y2){

    /*canvas.getObjects().map(function (o) {
        canvas.remove(o);
    });*/

    if(x2 < 0 || y2 < 0){
        arrowX = arrowObj.left;
        arrowY = arrowObj.top;
        arrowObj.set({ left: x1, top: y1, angle: 90});
        /*if(arrowX >= 0 && arrowY >= 0){
            var line = new fabric.Line([arrowX, arrowY, x1, y1], {
                selectable: false,
                strokeWidth: 5 * canvasScale,
                strokeDashArray: [8 * canvasScale, 2 * canvasScale],
                stroke: 'darkblue',
                opacity: 0.5
            });
            canvas.add(line);
        }*/
        arrowX = x1;
        arrowY = y1;
        canvas.fire('object:modified', {target: arrowObj});
        canvas.renderAll();

        updateTargetProperty(x1, y1, 0);
    }else{
        var x = Math.abs(x1 - x2);
        var y = Math.abs(y1 - y2);
        var z = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        var cos = y / z;
        var r = Math.acos(cos);
        var angle = 180 / (Math.PI / r);

        if(x2 > x1 && y2 > y1){
            angle = 180 - angle;
        }

        if(x2 == x1 && y2 > y1){
            angle = 180;
        }

        if(x2 > x1 && y2 == y1){
            angle = 90;
        }

        if(x2 < x1 && y2 > y1){
            angle = 180 + angle;
        }

        if(x2 < x1 && y2 == y1){
            angle = 270;
        }

        if(x2 < x1 && y2 < y1){
            angle = 360 - angle;
        }

        arrowObj.set({ left: x1, top: y1, angle: angle});

        canvas.fire('object:modified', {target: arrowObj});
        canvas.renderAll();

        angle = (angle - 90) < 0 ? 360 + (angle - 90) : angle - 90;

        updateTargetProperty(x1, y1, angle);
    }
}

function hidePathPoints(){

    if(canvas){

        canvas.deactivateAll();

        pathLines.forEach(function(obj){
            if(obj.line){
                canvas.remove(obj.line);
                canvas.remove(obj.triangle);
            }
        });

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    visible: false
                });
            }
        });

        canvas.renderAll();
    }
}

function showPathPoints(){

    if(canvas){

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    visible: true
                });
            }
        });

        pathLines.forEach(function(obj){
            repaintPathLine(obj);
        });

        canvas.renderAll();
    }

}

function enablePathPoints(enabled){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    selectable: enabled
                });
            }
        });
    }
}

function lockPathPoints(){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    lockMovementX: true,
                    lockMovementY: true,
                    lockRotation: true,
                    hasBorders: false,
                    hasControls: false,
                    hasRotatingPoint: false
                });
            }
        });
    }
}

function unlockPathPoints(){
    if(canvas){
        canvas.deactivateAll();

        var objects = canvas.getObjects("path-group");
        objects.forEach(function(obj){
            if(obj.objType && obj.objType == "pathpoint"){
                obj.set({
                    lockMovementX: false,
                    lockMovementY: false,
                    lockRotation: false,
                    hasBorders: true,
                    hasControls: true,
                    hasRotatingPoint: true
                });
            }
        });
    }
}

function insertPathPoint(objects){

    var data = [];

    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "addpathpoint",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                if(obj.items){
                    for(var i = 0; i < obj.items.length; i ++){
                        objects[i].object.id = obj.items[i].id;
                    }
                    savePath();
                }
            }
        },
        printAjaxResult
    );
}

function clearPathPoint(objects){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "clearpathpoint"
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                insertPathPoint(objects);
            }
        },
        printAjaxResult
    );
}

function insertPath(objects){

    var data = [];
    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "addpath",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                $.messager.alert("操作提示", "操作成功！","info", function(){
                });
            }
        },
        printAjaxResult
    );
}

function clearPath(objects){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "clearpath"
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                insertPath(objects);
            }
        },
        printAjaxResult
    );
}

function updatePathPoint(objects){
    var data = [];

    for(var i = 0; i < objects.length; i ++){
        data.push(objects[i].getData());
    }

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "setpathpoint",
            data: data
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }else{
                $.messager.alert("操作提示", "操作成功！","info", function(){
                });
            }
        },
        printAjaxResult
    );
}

function getPathPoint(){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "getpathpoint",
            startIndex: 0,
            endIndex: 1024
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }
            if(obj.items){
                for(var i = 0; i < obj.items.length; i ++){
                    var pix = posToPix(obj.items[i].pos_x, obj.items[i].pos_y);
                    var angle = directionToAngle(obj.items[i].pos_direct);
                    var clone = fabric.util.object.clone(nodeObj);
                    var width = nodeObj.width;
                    var height = nodeObj.height;
                    var scale = Math.min(svgSize / width, svgSize / height);
                    clone.set({
                        id: obj.items[i].id,
                        code: obj.items[i].code,
                        name: obj.items[i].name,
                        left: canvasScale * pix.x,
                        top: canvasScale * pix.y,
                        angle: angle,
                        scaleX: canvasScale * scale,
                        scaleY: canvasScale * scale,
                        objType: 'pathpoint',
                        selectable: false
                    });
                    canvas.add(clone);
                }

                canvas.renderAll();

                getPath();
            }
        },
        printAjaxResult
    );
}

function getPath(){

    postAjaxJsonRequest(
        URL_SENDDATA, 
        {
            action: "getpath",
            startIndex: 0,
            endIndex: 1024
        }, 
        function (obj) {
            if(obj.error != 0){
                $.messager.alert("错误", obj.action + "失败,错误码:" + obj.error, "error",function(){
                    return;
                });
            }
            console.log(obj);
            if(obj.items){
                var pathPoints = [];

                var objects = canvas.getObjects("path-group");
                objects.forEach(function(obj){
                    if(obj.objType && obj.objType == "pathpoint"){
                        pathPoints.push(obj);
                    }
                });

                for(var i = 0; i < obj.items.length; i ++){
                    var startObject = getPathPointById(pathPoints, obj.items[i].start_point);
                    var endObject = getPathPointById(pathPoints, obj.items[i].end_point);
                    if(startObject != null && endObject != null){
                        pathLines.push({
                            startObject: startObject, 
                            endObject: endObject,
                            type: obj.items[i].direction,
                            line: null,
                            triangle: null
                        });
                    }
                }

                pathLines.forEach(function(obj){
                    repaintPathLine(obj);
                });
            }
        },
        printAjaxResult
    );
}

function getPathPointById(pathPoints, id){
    for(var i = 0; i < pathPoints.length; i ++){
        if(pathPoints[i].id && pathPoints[i].id == id){
            return pathPoints[i];
        }
    }
    return null;
}

function savePathPoint(){

    canvas.deactivateAll();

    var pathPoints = [];

    var objects = canvas.getObjects("path-group");
    objects.forEach(function(obj){
        if(obj.objType && obj.objType == "pathpoint"){
            var pathPoint = new PathPoint(obj);
            pathPoints.push(pathPoint);
        }
    });

    clearPathPoint(pathPoints);
}

function savePath(){
    var paths = [];

    pathLines.forEach(function(object){
        var path = new Path(object);
        paths.push(path);
    });

    clearPath(paths);
}

//将机器人坐标复制到当前选中的路径节点
function cloneRobotPosition(){
    var activeObject = canvas.getActiveObject();
    if(robotObj && robotObj.left >= 0 && robotObj.top >= 0 && activeObject){
        canvas.deactivateAll();
        activeObject.set({
            left: robotObj.left,
            top: robotObj.top
        });
        canvas.fire('object:modified', {target: activeObject});
        canvas.renderAll();
        canvas.setActiveObject(activeObject.setCoords());
    }
}

//重新绘制一条路径
function repaintPathLine(obj){
    if(obj.line){
        canvas.remove(obj.line);
        canvas.remove(obj.triangle);
    }

    var startObject = obj.startObject;
    var endObject = obj.endObject;
    var stroke = '#324D5B';
    var dashArray = [];
    var isArrow = false;

    switch(obj.type){
        case 0:
        isArrow = false;
        break;
        case 1:
        isArrow = true;
        dashArray = [8 * canvasScale, 2 * canvasScale];
        break;
        default:
        break;
    }

    var line = new fabric.Line([startObject.left, startObject.top, endObject.left, endObject.top],{
        left: Math.min(startObject.left, endObject.left) - 4 * canvasScale / 2,
        top: Math.min(startObject.top, endObject.top) - 4 * canvasScale / 2,
        selectable: false,
        strokeWidth: 4 * canvasScale,
        strokeDashArray: dashArray,
        stroke: stroke,
        opacity: 0.3
    });

    obj.line = line;
    
    canvas.add(line);
    canvas.sendToBack(line);

    if(isArrow){
        var x1 = startObject.left,
            y1 = startObject.top,
            x2 = endObject.left,
            y2 = endObject.top,
            dx = x2 - x1,
            dy = y2 - y1;

        var angle = Math.atan2(dy, dx);

        angle *= 180 / Math.PI;
        angle += 90;

        var triangle = new fabric.Triangle({
            left: x2 - dx / 2,
            top: y2 - dy / 2,
            height: 10 * canvasScale,
            width: 10 * canvasScale,
            angle: angle,
            fill: stroke,
            originX: 'center',
            originY: 'center',
            selectable: false,
            opacity: 0.3
        });

        obj.triangle = triangle;

        canvas.add(triangle);
        canvas.sendToBack(triangle);
    }
}

//为选中的两个路径节点添加连接线
function connectPathPoint(type) {

    var activeGroup = canvas.getActiveGroup();
    if (activeGroup) {
        var objectsInGroup = activeGroup.getObjects();
        if(objectsInGroup.length == 2){

            disconnectPathPoint();

            var exist = false;
            var startIndex = (type == PATHPOINT_CONNECT_LEFT ? 0 : 1);
            var endIndex = (type == PATHPOINT_CONNECT_LEFT ? 1 : 0);
            for(var i = 0; i < pathLines.length; i ++){
                if(pathLines[i].startObject == objectsInGroup[startIndex] 
                    && pathLines[i].endObject == objectsInGroup[endIndex]){
                    exist = true;
                    break;
                }
                if(pathLines[i].endObject == objectsInGroup[startIndex] 
                    && pathLines[i].startObject == objectsInGroup[endIndex]){
                    exist = true;
                    break;
                }
            }

            if(!exist){
                pathLines.push({
                    startObject: objectsInGroup[startIndex], 
                    endObject: objectsInGroup[endIndex],
                    type: type == PATHPOINT_CONNECT_BOTH ? 0 : 1,
                    line: null,
                    triangle: null
                });

                var startObject = pathLines[pathLines.length - 1].startObject;
                var endObject = pathLines[pathLines.length - 1].endObject;

                canvas.deactivateAll();

                repaintPathLine(pathLines[pathLines.length - 1]);

                var objectList = new Array();

                objectsInGroup.forEach(function (object) {
                    object.set({
                        hasControls: true
                    });
                    objectList.push(object);
                });

                var objs = objectList.map(function (o) {
                    return o.set('active', true);
                });

                var selGroup = new fabric.Group(objs, {
                    originX: 'center',
                    originY: 'center'
                });

                canvas.setActiveGroup(selGroup.setCoords());
            }
            canvas.renderAll();
        }
    }
}

function removePathLineByObject(obj){
    for(var i = 0; i < pathLines.length; i ++){
        if(pathLines[i].startObject == obj || pathLines[i].endObject == obj){
            if(pathLines[i].line){
                canvas.remove(pathLines[i].line);
                canvas.remove(pathLines[i].triangle);
            }
            pathLines.splice(i, 1);
            disconnectPathPoint(obj);
        }
    }
}

function disconnectPathPoint(){
    var activeObject = canvas.getActiveObject();
    var activeGroup = canvas.getActiveGroup();
    if (activeGroup) {
        var objectsInGroup = activeGroup.getObjects();
        if(objectsInGroup.length == 2){
            for(var i = 0; i < pathLines.length; i ++){
                if((pathLines[i].startObject == objectsInGroup[0] && pathLines[i].endObject == objectsInGroup[1]) || 
                    (pathLines[i].startObject == objectsInGroup[1] && pathLines[i].endObject == objectsInGroup[0])){
                    if(pathLines[i].line){
                        canvas.remove(pathLines[i].line);
                        canvas.remove(pathLines[i].triangle);
                    }
                    pathLines.splice(i, 1);
                    break;
                }
            }
            canvas.renderAll();
        }
    }
    else if (activeObject) {
        removePathLineByObject(activeObject);
        canvas.renderAll();
    }
}

//删除所选的路径节点
function removePathPoint() {
    var activeObject = canvas.getActiveObject();
    var activeGroup = canvas.getActiveGroup();
    if (activeGroup) {
        $.messager.confirm('确认','删除是不可恢复的，你确认要删除选定路径节点吗？',function(res) {
            if(res) {
                var objectsInGroup = activeGroup.getObjects();
                canvas.discardActiveGroup().renderAll();
                objectsInGroup.forEach(function (object) {
                    removePathLineByObject(object);
                    canvas.remove(object);
                });
                canvas.renderAll();
            }
        });
    }
    else if (activeObject) {
        $.messager.confirm('确认','删除是不可恢复的，你确认要删除选定路径节点吗？',function(res) {
            if(res) {
                removePathLineByObject(activeObject);
                canvas.remove(activeObject);
                canvas.renderAll();
            }
        });
    }
}

//增加路径节点
function addPathPoint(x, y) {
    if(drawMode == DRAW_MODE_SET_EDIT && x >= 0 && y >= 0){
        var clone = fabric.util.object.clone(nodeObj);
        var width = nodeObj.width;
        var height = nodeObj.height;
        var scale = Math.min(svgSize / width, svgSize / height);
        clone.set({
            left: x,
            top: y,
            scaleX: canvasScale * scale,
            scaleY: canvasScale * scale,
            objType: 'pathpoint'
        });
        canvas.add(clone); 
        canvas.renderAll();
    }
}

function initCanvas(){

    canvas = new fabric.Canvas('map_canvas', {
        allowTouchScrolling: true,
        renderOnAddRemove: false,
        enableRetinaScaling: true,
        selection: false
    });

    fabric.Object.prototype.set({
        padding: 6,
        transparentCorners: false,
        borderColor: '#999999',
        cornerColor: '#999999',
        cornerSize: 8
    });

    //指定节点类型
    fabric.Object.prototype.objType = "";
    //指定节点ID|英文标识|中文名称
    fabric.Object.prototype.id = null;
    fabric.Object.prototype.code = null;
    fabric.Object.prototype.name = null;


    fabric.Group.prototype.set({
        hasControls: false,
        hasRotatingPoint: false
    });
    


    fabric.Image.fromURL(path + 'map/' + mapName + '.jpg', function(oImg) {

        bgImg = oImg;

        bgImg.scale(canvasScale);

        mapWidth = bgImg.getWidth();
        mapHeight = bgImg.getHeight();

        canvas.setBackgroundImage(bgImg);

        canvas.setWidth(mapWidth);
        canvas.setHeight(mapHeight);

        var ruler = 100;
        var stroke = "#000000";

        var group = new fabric.Group();

        for(var i = ruler; i < mapWidth;){
            var line = new fabric.Line([0, 0, 0, mapHeight], {
                left: i,
                top: 0,
                selectable: false,
                strokeWidth: 0.5,
                stroke: stroke,
                opacity: 0.3
            });
            group.add(line);
            if(i % (2 * ruler) == 0){
                var text = new fabric.Text(i * mapResolution + "", {
                    left: i,
                    top: 5,
                    selectable: false,
                    originX: 'center', 
                    originY: 'center',
                    fontSize: 12,
                    fill: stroke,
                    opacity: 0.3
                });
                group.add(text);
            }
            i += ruler;
        }

        for(var i = ruler; i < mapHeight;){
            var line = new fabric.Line([0, 0, mapWidth, 0], {
                left: 0,
                top: i,
                selectable: false,
                strokeWidth: 0.5,
                stroke: stroke,
                opacity: 0.3
            });
            group.add(line);
            if(i % (2 * ruler) == 0){
                var text = new fabric.Text(i * mapResolution + "", {
                    left: 0,
                    top: i,
                    selectable: false,
                    originX: 'left', 
                    originY: 'center',
                    fontSize: 12,
                    fill: stroke,
                    opacity: 0.3
                });
                group.add(text);
            }
            i += ruler;
        }

        canvas.add(group);

        //加载路径节点图标
        fabric.loadSVGFromURL(nodeSrc, function (objects, options) {
            nodeObj = fabric.util.groupSVGElements(objects, options);
            var width = nodeObj.width;
            var height = nodeObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            nodeObj.set({
                left: 200, 
                top: 200, 
                selectable: true,
                hoverCursor: 'pointer',
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.6,
                angle: 0});
            nodeObj.setControlsVisibility({
                mt: false, 
                mb: false, 
                ml: false, 
                mr: false, 
                bl: false,
                br: false, 
                tl: false, 
                tr: false,
                mtr: true
            });
            //canvas.add(nodeObj);

            getPathPoint();

            //canvas.renderAll();
        });

        //加载目标点图标
        fabric.loadSVGFromURL(arrowSrc, function (objects, options) {
            arrowObj = fabric.util.groupSVGElements(objects, options);
            var width = arrowObj.width;
            var height = arrowObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            arrowObj.set({ 
                left: -1000, 
                top: -1000, 
                selectable: false,
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.8,
                angle: 0});
            canvas.add(arrowObj);

            canvas.renderAll();
        });

        //加载机器人图标
        fabric.loadSVGFromURL(robotSrc, function (objects, options) {
            robotObj = fabric.util.groupSVGElements(objects, options);
            var width = robotObj.width;
            var height = robotObj.height;
            var scale = Math.min(svgSize / width, svgSize / height);
            robotObj.set({ 
                left: -1000, 
                top: -1000, 
                selectable: false,
                originX: 'center', 
                originY: 'center',
                scaleX: scale,
                scaleY: scale,
                opacity: 0.8,
                angle: 0});
            canvas.add(robotObj);

            canvas.renderAll();

            startAnimateRobot();
            //animate(robotObj, 3);

        });
        canvas.calcOffset();
    });

    /*function animate(obj, times) {
        var t = times;
        obj.setOpacity(0).animate({opacity: 1}, {
            duration: 500,
            onComplete: function(){
                if(t -- > 0){      
                    obj.setOpacity(1).animate({opacity: 0},{
                        duration: 500,
                        onComplete: function(){
                            animate(obj, -- t);
                        }
                    });
                }
            },
        });
    }

    (function render(){
        canvas.renderAll();
        fabric.util.requestAnimFrame(render);
    })();*/

    canvas.on({
        "object:selected":function(evt){
            if(evt.target && evt.target.objType && evt.target.objType == 'pathpoint'){
                updatePathPointProperty(evt.target.id, evt.target.code, evt.target.name, evt.target.left, evt.target.top, evt.target.angle);
            }
        },
        "object:modified":function(evt){

            var activeObject = canvas.getActiveObject();

            if(activeObject && activeObject.objType == 'pathpoint'){
                updatePathPointProperty(activeObject.id, activeObject.code, activeObject.name, activeObject.left, activeObject.top, activeObject.angle);
            }

            var repaintPathLines = false;
            var isGroup = false;

            if(evt.target && evt.target.objects){
                isGroup = true;
                evt.target.objects.forEach(function(obj){
                    if(obj.objType == 'pathpoint'){
                        repaintPathLines = true;
                    }
                })
                canvas.deactivateAll();
            }

            if((evt.target && evt.target.objType && evt.target.objType == 'pathpoint') || repaintPathLines){
                pathLines.forEach(function(obj){
                    repaintPathLine(obj);
                });

                if(isGroup){
                    var objectList = new Array();

                    evt.target.objects.forEach(function (object) {
                        object.set({
                            hasControls: true
                        });
                        objectList.push(object);
                    });

                    var objs = objectList.map(function (o) {
                        return o.set('active', true);
                    });

                    var selGroup = new fabric.Group(objs, {
                        originX: 'center',
                        originY: 'center'
                    });

                    canvas.setActiveGroup(selGroup.setCoords());

                }

                canvas.renderAll();
            }
        },
        "object:moving":function(evt){

            var repaintPathLines = false;
            var isGroupSelect = false;

            if(evt.target && evt.target.objects){
                isGroupSelect = true;
                evt.target.objects.forEach(function(obj){
                    if(obj.objType == 'pathpoint'){
                        repaintPathLines = true;
                    }
                })
            }

            if((evt.target && evt.target.objType && evt.target.objType == 'pathpoint') || repaintPathLines){
                pathLines.forEach(function(obj){

                    if(obj.line){
                        canvas.remove(obj.line);
                        canvas.remove(obj.triangle);
                    }

                    if(!isGroupSelect){
                        //repaintPathLine(obj);
                        //canvas.renderAll();
                    }
                });
            }
        },
        "mouse:down":function(evt){
            dragmove = true;
            switch(drawMode){
                case DRAW_MODE_BROWSE:
                scrollX = evt.e.layerX;
                scrollY = evt.e.layerY;
                break;
                case DRAW_MODE_SET_DIRECTION:
                clickX = evt.e.layerX;
                clickY = evt.e.layerY;
                updateArrow(clickX, clickY, -1, -1);
                break;
                case DRAW_MODE_SET_EDIT:
                clickX = evt.e.layerX;
                clickY = evt.e.layerY;
                /*var newNodeObj = fabric.util.object.clone(nodeObj);
                newNodeObj.set({
                    left: clickX, 
                    top: clickY, 
                    selectable: true
                });
                canvas.add(newNodeObj);*/
                break;
                default:
                break;
            }
        },
        "mouse:move":function(evt){
            if(dragmove) {
                switch(drawMode){
                    case DRAW_MODE_BROWSE:
                    break;
                    case DRAW_MODE_SET_DIRECTION:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    updateArrow(clickX, clickY, moveX, moveY);
                    break;
                    case DRAW_MODE_SET_EDIT:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    default:
                    break;
                }
            }
        },
        "mouse:up":function(evt){
            if(dragmove) {
                switch(drawMode){
                    case DRAW_MODE_BROWSE:
                    var map_div = $("#map_div");

                    map_div.scrollLeft(map_div.scrollLeft() - evt.e.layerX + scrollX);
                    map_div.scrollTop(map_div.scrollTop() - evt.e.layerY + scrollY);

                    scrollX = evt.e.layerX;
                    scrollY = evt.e.layerY;
                    break;
                    case DRAW_MODE_SET_DIRECTION:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    case DRAW_MODE_SET_EDIT:
                    moveX = evt.e.layerX;
                    moveY = evt.e.layerY;
                    break;
                    default:
                    break;
                }
                dragmove = false;
            }
        }
    });
}

$(document).ready(function(){

    $("#map_div").scroll(function() {
        canvas.calcOffset();
    });
    $("#map_div").resize(function() {
        canvas.calcOffset();
    });

    $('#browse_btn').bind('click', function(){setDrawMode(DRAW_MODE_BROWSE);});
    $('#call_btn').bind('click', function(){setDrawMode(DRAW_MODE_SET_DIRECTION);});
    $('#edit_btn').bind('click', function(){setDrawMode(DRAW_MODE_SET_EDIT);});

    $('#refresh_btn').bind('click', reloadMap);
    $('#zoomin_btn').bind('click', zoomIn);
    $('#zoomout_btn').bind('click', zoomOut);
    $('#navwin_btn').bind('click', initNavWin);

    $('#addpathpoint_btn').bind('click', function(){addPathPoint(clickX, clickY);});
    $('#removepathpoint_btn').bind('click', removePathPoint);
    $('#connectpathpoint_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_BOTH);});
    $('#connectpathpointleft_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_LEFT);});
    $('#connectpathpointright_btn').bind('click', function(){connectPathPoint(PATHPOINT_CONNECT_RIGHT);});
    $('#disconnectpathpoint_btn').bind('click', function(){disconnectPathPoint();});
    $('#savepathpoint_btn').bind('click', savePathPoint);
    $('#lock_btn').bind('click', lockPathPoints);
    $('#unlock_btn').bind('click', unlockPathPoints);
    $('#robot_btn').bind('click', cloneRobotPosition);


    $('#forward_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_FORWARD);});
    $('#forward_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#left_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_TURNLEFT);});
    $('#left_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#backward_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_BACKWARD);});
    $('#backward_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});
    $('#right_btn').bind('mousedown', function(){onpress(CTRL_CODE_ROBOT_TURNRIGHT);});
    $('#right_btn').bind('mouseup mouseleave', function(){onrelease(CTRL_CODE_ROBOT_STOP);});

    $('#rotate_btn').bind('click', setDirection);

    $('#initto_btn').bind('click', function(){sendLocationCtrl(CTRL_CODE_ROBOT_INIT_MOVETO);});
    $('#moveto_btn').bind('click', function(){sendLocationCtrl(CTRL_CODE_ROBOT_MOVETO);});


    $("#refresh_sb").switchbutton({
        onChange: function(checked){
            if(checked){
                startRefreshingMap();
            }else{
                stopRefreshingMap();
            }
        }
    });

    $("#zoom_cb").combobox({
        editable : false,
        data:[{
            text: '50%',
            value: 0.5
        },{
            text: '60%',
            value: 0.6
        },{
            text: '70%',
            value: 0.7
        },{
            text: '80%',
            value: 0.8
        },{
            text: '90%',
            value: 0.9
        },{
            text: '100%',
            value: 1
        },{
            text: '110%',
            value: 1.1
        },{
            text: '120%',
            value: 1.2
        },{
            text: '130%',
            value: 1.3
        },{
            text: '140%',
            value: 1.4
        },{
            text: '150%',
            value: 1.5
        },{
            text: '200%',
            value: 2
        }],
        onChange: function(newValue, oldValue){
            zoomTo(newValue);
        }
    });

    $("#zoom_cb").combobox('setValue', 1);

    $('#map_pg').propertygrid({
        width: 'auto',
        height: 'auto',
        showGroup: true,
        scrollbarSize: 0,
        columns: [[
        { field: 'name', title: '属性', width: 100, resizable: true },
        { field: 'value', title: '值', width: 100, resizable: true }
        ]],
        onAfterEdit: function(index, row, changes){
            if(changes.value){
                var data = $('#map_pg').propertygrid('getData');

                var x = Math.round((data.rows[0].value - mapOriginX) / mapResolution);
                var y = - Math.round((data.rows[1].value - mapOriginY - mapHeight * mapResolution) / mapResolution);
                var angle = (data.rows[2].value + 90) > 360 ? data.rows[2].value + 90 - 360 : data.rows[2].value + 90;

                arrowObj.set({ left: Math.round(x * canvasScale), top: Math.round(y * canvasScale), angle: angle});
                canvas.fire('object:modified', {target: arrowObj});
                canvas.renderAll();
            }
        }
    });  

    $('#edit_pg').propertygrid({
        width: 'auto',
        height: 'auto',
        showGroup: true,
        scrollbarSize: 0,
        columns: [[
        { field: 'name', title: '属性', width: 100, resizable: true },
        { field: 'value', title: '值', width: 100, resizable: true }
        ]],
        onAfterEdit: function(index, row, changes){
            if(changes.value){
                var data = $('#edit_pg').propertygrid('getData');

                var objects = canvas.getObjects("path-group");
                objects.forEach(function(obj){

                    if(obj.objType && obj.objType == "pathpoint" && obj.id == parseInt(data.rows[0].value)){

                        var pix = posToPix(data.rows[3].value, data.rows[4].value);

                        var x = pix.x;
                        var y = pix.y;
                        var angle = directionToAngle(data.rows[5].value);

                        var activeObject = canvas.getActiveObject();

                        canvas.deactivateAll();

                        obj.set({
                            left: Math.round(x * canvasScale),
                            top: Math.round(y * canvasScale),
                            angle: angle,
                            code: data.rows[1].value,
                            name: data.rows[2].value
                        });

                        canvas.fire('object:modified', {target: obj});
                        canvas.renderAll();

                        pathLines.forEach(function(obj){
                            repaintPathLine(obj);
                        });

                        if(activeObject){
                            canvas.setActiveObject(activeObject.setCoords());
                        }
                    }
                });
            }
        }
    });  

    loadMapSettings();

    setDrawMode(DRAW_MODE_BROWSE);

});