const IDLE           = 0;
const OPENING        = 1;
const BUFFERING      = 2;
const PLAYING        = 3;
const PAUSED         = 4;
const STOPPING       = 5;
const ENDED          = 6;
const ERROR          = 7;



const KEY_CODE_LEFT              			        = 37;
const KEY_CODE_UP                			        = 38;
const KEY_CODE_RIGHT                			    = 39;
const KEY_CODE_DOWN              			        = 40;


const DRAW_MODE_BROWSE                			    = 0;
const DRAW_MODE_SET_DIRECTION         			    = 1;
const DRAW_MODE_SET_EDIT         					= 2;


const ROBOT_CLIENT_MANUAL                         = 0x10;   //进入手动控制模式
const ROBOT_CLIENT_MANUAL_OVER                    = 0x11;   //结束手动控制模式
const ROBOT_CLIENT_MANUAL_OK                      = 0x20;   //进入手动模式成功
const ROBOT_CLIENT_MANUAL_REJECT                  = 0x21;   //进入手动模式被拒绝

const ROBOT_CLIENT_MODE_MANUAL_WEB                = 0x13;   //WEB手动控制模式
const ROBOT_CLIENT_MODE_MANUAL_CLIENT             = 0x14;   //客户端手动控制模式
const ROBOT_CLIENT_MODE_ONMISSION                 = 0x15;   //任务进行模式
const ROBOT_CLIENT_MODE_GAMEPAD                   = 0x16;   //手柄控制
const ROBOT_CLIENT_MODE_DISABLE                   = 0x17;   //不能控制
//{"action":9,"mode":X}

//MSGTYPE send to cradle
const NSNK_MSGTYPE_CRADLE                         = 43;  //云台控制
const NSNK_MSGTYPE_INFRARED                       = 46;  //红外及雨刷控制
const NSNK_MSGTYPE_TEMPERATURE                    = 42;  //手动测温
const NSNK_MSGTYPE_PRESETSAVE                     = 39;  //设置预置位
const NSNK_MSGTYPE_PRESETLOAD                     = 40;  //调用预置位
const NSNK_MSGTYPE_PRESETDELETE                   = 41;  //删除预置位

//COMMAND send to cradle
const NSNK_PTZ_UPLEFTSTOP                         = 0x0701;  //云台左上方向运动停止
const NSNK_PTZ_UPLEFT                             = 0x0702;  //云台左上方向运动
const NSNK_PTZ_DOWNLEFTSTOP                       = 0x0703;  //云台左下方向运动停止
const NSNK_PTZ_DOWNLEFT                           = 0x0704;  //云台左下方向运动
const NSNK_PTZ_PANLEFTSTOP                        = 0x0503;  //云台左转停止
const NSNK_PTZ_PANLEFT                            = 0x0504;  //云台左转
const NSNK_PTZ_TILTUPSTOP                         = 0x0401;  //云台向上停止
const NSNK_PTZ_TILTUP                             = 0x0402;  //云台向上
const NSNK_PTZ_TILTDOWNSTOP                       = 0x0403;  //云台向下停止
const NSNK_PTZ_TILTDOWN                           = 0x0404;  //云台向下
const NSNK_PTZ_UPRIGHTSTOP                        = 0x0801;  //云台右上方向运动停止
const NSNK_PTZ_UPRIGHT                            = 0x0802;  //云台右上方向运动
const NSNK_PTZ_DOWNRIGHTSTOP                      = 0x0803;  //云台右下方向运动停止
const NSNK_PTZ_DOWNRIGHT                          = 0x0804;  //云台右下方向运动
const NSNK_PTZ_PANRIGHTSTOP                       = 0x0501;  //云台右转停止
const NSNK_PTZ_PANRIGHT                           = 0x0502;  //云台右转
const NSNK_PTZ_ZOOMINSTOP                         = 0x0301;  //可见光放大(拉近)停止
const NSNK_PTZ_ZOOMIN                             = 0x0302;  //可见光放大(拉近)
const NSNK_PTZ_ZOOMOUTSTOP                        = 0x0303;  //可见光缩小(拉远)停止
const NSNK_PTZ_ZOOMOUT                            = 0x0304;  //可见光缩小(拉远)

const NSNK_PTZ_IFR_AUTO_RECTIFY                   = 0x0B08;  //红外调零
const NSNK_PTZ_IFR_FOCUS_NEAR                     = 0x0B09;  //红外手动近焦
const NSNK_PTZ_IFR_FOCUS_FAR                      = 0x0B0A;  //红外手动远焦
const NSNK_PTZ_IFR_FOCUS_STOP                     = 0x0B0B;  //红外停止调焦
const NSNK_PTZ_IFR_AUTO_FOCUS                     = 0x0B0C;  //红外自动调焦
const NSNK_PTZ_OPEN_RAIN                          = 0x0B0D;  //打开雨刷
const NSNK_PTZ_CLOSE_RAIN                         = 0x0B0E;  //关闭雨刷

const CTRL_CODE_CRADLE_UP_START                   = 0x00;    //云台向上 开始
const CTRL_CODE_CRADLE_UP_STOP                    = 0x01;    //云台向上 停止
const CTRL_CODE_CRADLE_UPLEFT_START               = 0x02;    //云台向左上 开始
const CTRL_CODE_CRADLE_UPLEFT_STOP                = 0x03;    //云台向左上 停止
const CTRL_CODE_CRADLE_UPRIGHT_START              = 0x04;    //云台向右上 开始
const CTRL_CODE_CRADLE_UPRIGHT_STOP               = 0x05;    //云台向右上 停止
const CTRL_CODE_CRADLE_LEFT_START                 = 0x06;    //云台向左 开始
const CTRL_CODE_CRADLE_LEFT_STOP                  = 0x07;    //云台向左 停止
const CTRL_CODE_CRADLE_RIGHT_START                = 0x08;    //云台向右 开始
const CTRL_CODE_CRADLE_RIGHT_STOP                 = 0x09;    //云台向右 停止
const CTRL_CODE_CRADLE_DOWN_START                 = 0x0A;    //云台向下 开始
const CTRL_CODE_CRADLE_DOWN_STOP                  = 0x0B;    //云台向下 停止
const CTRL_CODE_CRADLE_DOWNLEFT_START             = 0x0C;    //云台向左下 开始
const CTRL_CODE_CRADLE_DOWNLEFT_STOP              = 0x0D;    //云台向左下 停止
const CTRL_CODE_CRADLE_DOWMRIGHT_START            = 0x0E;    //云台向右下 开始
const CTRL_CODE_CRADLE_DOWMRIGHT_STOP             = 0x0F;    //云台向右下 停止
const CTRL_CODE_VIDEO_ZOOMIN_START                = 0x12;    //可见光倍率放大 开始
const CTRL_CODE_VIDEO_ZOOMIN_STOP                 = 0x13;    //可见光倍率放大 停止
const CTRL_CODE_VIDEO_ZOOMOUT_START               = 0x14;    //可见光倍率缩小 开始
const CTRL_CODE_VIDEO_ZOOMOUT_STOP                = 0x15;    //可见光倍率缩小 停止
const CTRL_CODE_INFRARED_FOCUS_START              = 0x16;    //红外调焦 开始
const CTRL_CODE_INFRARED_FOCUS_STOP               = 0x17;    //红外调焦 停止
const CTRL_CODE_INFRARED_RESET                    = 0x18;    //红外重置 (调零)
const CTRL_CODE_CRADLE_WIPER_ON                   = 0x19;    //云台雨刷 开
const CTRL_CODE_CRADLE_WIPER_OFF                  = 0x20;    //云台雨刷 关
const CTRL_CODE_CRADLE_GETINFO                    = 0x21;    //获取云台工况
const CTRL_CODE_VIDEO_SNAPSHOT                    = 0x22;    //可见光截图

const CTRL_CODE_MISSION_START                     = 0x30;    //开始执行巡检任务


const CTRL_CODE_ROBOT_FORWARD                     = 0x01;    //前进(带速度 百分比)
const CTRL_CODE_ROBOT_TURNLEFT                    = 0x02;    //左转(带速度 百分比)
const CTRL_CODE_ROBOT_BACKWARD                    = 0x03;    //后退(带速度 百分比)
const CTRL_CODE_ROBOT_TURNRIGHT                   = 0x04;    //右转(带速度 百分比)
const CTRL_CODE_ROBOT_STOP                        = 0x05;    //停止
const CTRL_CODE_ROBOT_INIT_MOVETO                 = 0x06;    //初始状态发坐标的控制(坐标和方向)
const CTRL_CODE_ROBOT_MOVETO                      = 0x07;    //发坐标的控制(坐标和方向)
const CTRL_CODE_ROBOT_GETPOS                      = 0x08;    //获取位置信息(坐标和方向)
const CTRL_CODE_ROBOT_GETCTRLMODE                 = 0x09;    //获取控制模式
const CTRL_CODE_ROBOT_KEEPSTOP                    = 0x18;    //急停
const CTRL_CODE_ROBOT_ROTATE                      = 0x19;    //旋转



const ROBOT_STATE                                 = 0x60;
const ROBOT_EVENT                                 = 0x61;
const ROBOT_BODY_MAP                              = 0x64;
const ROBOT_CURRENT_POSE                          = 0x65;
const ROBOT_ARRIVE_GOAL                           = 0x66;
const ROBOT_ROTATE_RESULT                         = 0x68;
const ROBOT_CENTRALIZE                            = 0x69;




//获取位置信息,当前坐标和朝向
//获取速度
//电池电量
//车内温度
//车外温度
//电机状态



//退出手动控制
//进入手动控制(前序任务处理方式 继续执行 | 中断)


//红外：调零、调焦

//工况：云台、可见光、红外、雨刷是否开启
//分析：

const PATHPOINT_CONNECT_BOTH                      = 0x01;
const PATHPOINT_CONNECT_LEFT                      = 0x02;
const PATHPOINT_CONNECT_RIGHT                     = 0x03;


var canvasScale = 1;
var mapWidth, mapHeight, mapResolution, mapOriginX, mapOriginY;


$.extend($.fn.datagrid.defaults.editors, {
    intbox: {
        init: function(container, options){
            var input = $('<input type="text" class="datagrid-editable-input">').appendTo(container);
            return input;
        },
        destroy: function(target){
            $(target).remove();
        },
        getValue: function(target){
            return parseInt($(target).val());
        },
        setValue: function(target, value){
            $(target).val(value);
        },
        resize: function(target, width){
            $(target)._outerWidth(width);
        }
    }
});

$.extend($.fn.datagrid.defaults.editors, {
    floatbox: {
        init: function(container, options){
            var input = $('<input type="text" class="datagrid-editable-input">').appendTo(container);
            return input;
        },
        destroy: function(target){
            $(target).remove();
        },
        getValue: function(target){
            return parseFloat($(target).val());
        },
        setValue: function(target, value){
            $(target).val(value);
        },
        resize: function(target, width){
            $(target)._outerWidth(width);
        }
    }
});

function printAjaxResult(obj){
	console.log(obj);
}

function postAjaxJsonRequest(url, data, callbacksuccess, callbackerror){
    $.ajax({
        url: url,
        type: "POST",
        dataType: 'json',
        data: {
            strRequest: JSON.stringify(data)
        },
        success: callbacksuccess,
        error: callbackerror
    });
}

function pixToPos(x, y){
	var posx = x * mapResolution + mapOriginX;
	var posy = mapHeight * mapResolution - y * mapResolution + mapOriginY;
	return {
		posx: posx,
		posy: posy
	};
}

function posToPix(posx, posy){
	var x = Math.round((posx - mapOriginX) / mapResolution);
	var y = - Math.round((posy - mapOriginY - mapHeight * mapResolution) / mapResolution);
	return {
		x: x,
		y: y
	};
}

function angleToDirection(angle){
	var direction = (angle - 90) < 0? 360 + angle - 90 : angle - 90;
	return direction;
}

function directionToAngle(direction){
	if(direction < 0){
		direction += 360;
	}
	var angle = (direction + 90) > 360 ? direction + 90 - 360 : direction + 90;
	return angle;
}


//路径节点表
function PathPoint(object){
	this.data = null;
	this.x = object.left / canvasScale;
	this.y = object.top / canvasScale;
	this.angle = object.angle;
	this.object = object;

	this.getData = function(){
		var pos = pixToPos(this.x, this.y);
		var direction = angleToDirection(this.angle);

		this.data = {
			id: this.object.id ? this.object.id : 0,
			code: this.object.code ? this.object.code : '',
			name: this.object.name ? this.object.name : '',
			pos_x: pos.posx,
			pos_y: pos.posy,
			pos_direct: direction,
			point_type: 0, 			                //节点类型 0普通路径节点 1巡检路径节点 2充电路径节点 3停靠路径节点
			deviation: this.object.deviation
		};

		return this.data;
	}
}

//路径表
function Path(object){
	this.data = null;

	var difX = object.endObject.left - object.startObject.left;
	var difY = object.endObject.top - object.startObject.top;
	this.pathlength = Math.pow((difX *difX + difY * difY), 0.5);

	this.getData = function(){

		this.data = {
			id: object.id ? object.id : 0,
			start_point: object.startObject.id,							//起始路径节点
			end_point: object.endObject.id,								//结束路径节点
			direction: object.type, 	                                //方向 0双向 1单向：起始到结束
			pathlength: this.pathlength									//路径长度
		};

		return this.data;
	}
}


























